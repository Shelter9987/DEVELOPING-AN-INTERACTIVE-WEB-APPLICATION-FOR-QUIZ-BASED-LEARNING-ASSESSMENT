// "use client";
// import { Button, Image } from "@nextui-org/react";
// import React, { useState } from "react";
// import Modalcomponent from "./Modalcomponent";
// import CreateQuize from "./createQuize";
// import QuestionList from "./QuestionList";
// import { useContext, useEffect } from "react";
// import { Context } from "@/utils/Context";

// const QuizCard = ({ quiz }) => {
//   const { user } = useContext(Context);
//   const {
//     title,
//     marks_allocated,
//     courseId,
//     createdBy,
//     start_time,
//     end_time,
//     desc,
//   } = quiz;

//   const [isOpen, setIsOpen] = useState(false);
//   const [ComponentToRender, setComponentToRender] = useState(null);
//   const [modaltitle, setModalTitle] = useState("");

//   const handleOpenModal = (Component, title) => {
//     setModalTitle(title);
//     setComponentToRender(() => Component);
//     setIsOpen(true);
//   };

//   return (
//     <>
//       <div className="mx-auto my-8 mb-4 overflow-hidden rounded-xl bg-foreground p-4 shadow">
//         <div className="flex items-end justify-end border-b border-border p-4">
//           <div className="flex items-center">
//             Quize by:
//             <div className="ml-3">
//               <h4 className="text-md font-medium text-gray-900">
//                 {createdBy.first_name} {createdBy.last_name}
//               </h4>
//               <p className="text-sm text-gray-500">{createdBy.email}</p>
//             </div>
//           </div>
//         </div>
//         <div className="flex flex-col items-center justify-center gap-2">
//           {/* Title Section */}
//           <h2 className="text-center text-2xl font-bold text-gray-900">
//             {title}
//           </h2>
//           {desc && (
//             <p className="text-sm text-gray-500">
//               Instructions <br /> {desc}
//             </p>
//           )}

//           <p className="text-sm text-gray-500">
//             Marks Allocated: {marks_allocated}
//           </p>
//           <div className="flex justify-between gap-4">
//             <span>
//               <strong>Quiz Time:</strong>
//             </span>
//             <p className="text-sm text-gray-500">
//               {start_time
//                 ? new Date(start_time).toLocaleString()
//                 : "Not set yet"}
//             </p>
//             to
//             <p className="text-sm text-gray-500">
//               {end_time ? new Date(end_time).toLocaleString() : "Not set yet"}
//             </p>
//           </div>

//           <div>
//             <h3 className="text-lg text-gray-900">
//               Course:{" "}
//               <span className="text-lg font-semibold text-gray-900">
//                 {courseId.course_name} ({courseId.course_code})
//               </span>
//             </h3>
//           </div>
//         </div>
//         {user?.role !== "student" && (
//           <div className="flex items-center justify-end gap-5">
//             <Button
//               color="primary"
//               onClick={() =>
//                 handleOpenModal(
//                   <QuestionList quize={quiz} />,
//                   "Update questions",
//                 )
//               }
//             >
//               Add Questions
//             </Button>
//             <Button color="success">Open quize</Button>
//             <Button color="danger">close quize</Button>
//             <Button
//               color="secondary"
//               onClick={() =>
//                 handleOpenModal(<CreateQuize quize={quiz} />, "Edit Quize")
//               }
//             >
//               Edit Quize
//             </Button>
//           </div>
//         )}
//       </div>
//       <Modalcomponent
//         title={modaltitle}
//         isOpen={isOpen}
//         setIsOpen={setIsOpen}
//         Component={ComponentToRender}
//         size="3xl"
//       />
//     </>
//   );
// };

// export default QuizCard;

"use client";
import { Button } from "@nextui-org/react";
import React, { useState, useContext } from "react";
import { Context } from "@/utils/Context";
import Modalcomponent from "./Modalcomponent";
import CreateQuize from "./createQuize";
import QuestionList from "./QuestionList";
import { Clock, Edit, BookOpen, Plus, Lock, User } from "lucide-react";

const QuizCard = ({ quiz }) => {
  const { user } = useContext(Context);
  const {
    title,
    marks_allocated,
    courseId,
    createdBy,
    start_time,
    end_time,
    desc,
  } = quiz;

  const [isOpen, setIsOpen] = useState(false);
  const [ComponentToRender, setComponentToRender] = useState(null);
  const [modaltitle, setModalTitle] = useState("");

  const handleOpenModal = (Component, title) => {
    setModalTitle(title);
    setComponentToRender(() => Component);
    setIsOpen(true);
  };

  const formatDate = (dateString) => {
    if (!dateString) return "Not set yet";
    return new Date(dateString).toLocaleString(undefined, {
      dateStyle: "medium",
      timeStyle: "short",
    });
  };

  const isTeacher = user?.role !== "student";

  return (
    <>
      <div className="mx-auto my-6 rounded-xl bg-white shadow-md transition-all hover:shadow-lg dark:bg-gray-800">
        {/* Card Header */}
        <div className="flex items-center justify-between rounded-t-xl bg-primary/10 p-4">
          <h2 className="text-2xl font-bold text-primary">{title}</h2>
          <div className="flex items-center gap-2 text-sm">
            <User className="h-4 w-4" />
            <div>
              <p className="font-medium">
                {createdBy.first_name} {createdBy.last_name}
              </p>
              <p className="text-xs text-gray-500">{createdBy.email}</p>
            </div>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-6">
          {/* Quiz Details */}
          <div className="mb-6 space-y-4">
            {desc && (
              <div className="rounded-lg bg-gray-50 p-4 dark:bg-gray-700/30">
                <h3 className="mb-2 font-medium">Instructions</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">{desc}</p>
              </div>
            )}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="flex items-center gap-2 rounded-md bg-green-50 p-3 dark:bg-green-900/20">
                <BookOpen className="h-5 w-5 text-green-600 dark:text-green-400" />
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Course</p>
                  <p className="font-medium">
                    {courseId.course_name} ({courseId.course_code})
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 rounded-md bg-blue-50 p-3 dark:bg-blue-900/20">
                <Clock className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Quiz Time</p>
                  <p className="text-sm">
                    {formatDate(start_time)} - {formatDate(end_time)}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-center rounded-md bg-purple-50 p-3 dark:bg-purple-900/20">
              <div className="text-center">
                <p className="text-xs text-gray-500 dark:text-gray-400">Marks Allocated</p>
                <p className="text-lg font-bold text-purple-700 dark:text-purple-400">
                  {marks_allocated}
                </p>
              </div>
            </div>
          </div>

          {/* Actions */}
          {isTeacher && (
            <div className="mt-6 flex flex-wrap items-center justify-end gap-3">
              <Button
                size="sm"
                radius="full"
                color="primary"
                variant="flat"
                startContent={<Plus size={16} />}
                onClick={() =>
                  handleOpenModal(
                    <QuestionList quize={quiz} />,
                    "Update questions"
                  )
                }
              >
                Add Questions
              </Button>
              
              <Button
                size="sm"
                radius="full"
                color="success"
                variant="flat"
                startContent={<BookOpen size={16} />}
              >
                Open Quiz
              </Button>
              
              <Button
                size="sm"
                radius="full"
                color="danger"
                variant="flat"
                startContent={<Lock size={16} />}
              >
                Close Quiz
              </Button>
              
              <Button
                size="sm"
                radius="full"
                color="secondary"
                variant="flat"
                startContent={<Edit size={16} />}
                onClick={() =>
                  handleOpenModal(<CreateQuize quize={quiz} />, "Edit Quiz")
                }
              >
                Edit Quiz
              </Button>
            </div>
          )}
        </div>
      </div>

      <Modalcomponent
        title={modaltitle}
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        Component={ComponentToRender}
        size="3xl"
      />
    </>
  );
};

export default QuizCard;