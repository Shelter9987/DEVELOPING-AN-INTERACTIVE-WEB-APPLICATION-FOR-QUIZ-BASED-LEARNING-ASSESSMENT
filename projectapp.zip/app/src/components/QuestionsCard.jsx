"use client";
import React, { useState } from "react";
import Modalcomponent from "./Modalcomponent";
import { Button } from "@nextui-org/react";
import QuestionForm from "@/app/(lecturer)/lecturer/questions/create/page";

const QuestionsCard = ({ question }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [ComponentToRender, setComponentToRender] = useState(null);
  const [modaltitle, setModalTitle] = useState("");

  const handleOpenModal = (Component, title) => {
    setModalTitle(title);
    setComponentToRender(() => Component);
    setIsOpen(true);
  };

  return (
    <>
      <div className="w-full rounded-xl bg-white p-6 shadow-md dark:bg-gray-800">
        <h2 className="mb-3 text-lg font-semibold text-gray-800 dark:text-white">
          {question?.questionText}
        </h2>

        <ul className="grid grid-cols-2 gap-3">
          {Object.entries(question?.options || {}).map(([key, value], index) => (
            <li
              key={index}
              className={`rounded-md border p-2 text-sm ${
                key === question.correctAnswer
                  ? "bg-yellow-100 font-semibold"
                  : "bg-gray-50"
              }`}
            >
              <span className="mr-2 font-bold text-gray-700">{key}:</span>
              <span className="text-gray-600">{value}</span>
            </li>
          ))}
        </ul>

        <div className="mt-4 flex justify-end">
          <Button
            color="secondary"
            onClick={() =>
              handleOpenModal(
                <QuestionForm question={question} />,
                "Edit Question"
              )
            }
          >
            Edit
          </Button>
        </div>
      </div>

      <Modalcomponent
        title={modaltitle}
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        Component={ComponentToRender}
        size="3xl"
      />
    </>
  );
};

export default QuestionsCard;
