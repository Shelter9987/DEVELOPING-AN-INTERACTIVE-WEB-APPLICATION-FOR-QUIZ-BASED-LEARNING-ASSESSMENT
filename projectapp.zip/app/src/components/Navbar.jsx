"use client";
import { Context } from "@/utils/Context";
import {
  Button,
  Navbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  NavbarMenu,
  NavbarMenuItem,
  NavbarMenuToggle,
} from "@nextui-org/react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useContext, useEffect, useState } from "react";
import { AiOutlineMenu } from "react-icons/ai";
import UserNavProfile from "./UserNavProfile";
import Modalcomponent from "@/components/Modalcomponent";
import MyWhiteboard from "./MyWhiteboard";
import AccountingCalculator from "./accounting-calculator";

export default function Navbartop() {
  const { user } = useContext(Context);

  const pathname = usePathname();
  const router = useRouter();

  const [isOpen, setIsOpen] = useState(false);
  const [ComponentToRender, setComponentToRender] = useState(null);
  const [title, setTitle] = useState("");

  const handleOpenModal = (Component, title) => {
    setTitle(title);
    setComponentToRender(() => Component);
    setIsOpen(true);
  };

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scroll, setScroll] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setScroll(true);
      } else {
        setScroll(false);
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const Navitems = [
    {
      name: "home",
      link: "/",
    },

    {
      name: "Accounting quizes",
      link: "/student/acc/quizzes",
    },

    {
      name: "Results",
      link: "/student/acc/results",
    },
    {
      name: "quizes",
      link: "/quizes",
    },
    {
      name: "quiz results",
      link: "/results",
    },
    // {
    //   name: "calculator",
    //   link: "/calculator",
    // },
  ];

  const Navlist = (
    <>
      {user?.role === "student" &&
        Navitems.map((item, i) => (
          <NavbarItem
            key={i}
            className="capitalize hover:text-secondary hover:underline"
            onClick={() => setIsMenuOpen(false)}
          >
            <Link href={item.link}>{item.name}</Link>
          </NavbarItem>
        ))}
      {user?.role === "lecturer" && (
        <>
          <NavbarItem
            className="capitalize hover:text-secondary hover:underline"
            onClick={() => setIsMenuOpen(false)}
          >
            <Link href={"/"}>Home</Link>
          </NavbarItem>
          <NavbarItem
            className="capitalize hover:text-secondary hover:underline"
            onClick={() => setIsMenuOpen(false)}
          >
            <Link href={"/lecturer/quizes"}>Quizes</Link>
          </NavbarItem>
        </>
      )}
    </>
  );

  const authBtn = (
    <>
      {user ? (
        <UserNavProfile />
      ) : (
        <Button
          color="primary"
          className="text-copy"
          size="lg"
          variant="ghost"
          as={Link}
          href={`/login?callback=${pathname}/`}
        >
          Login
        </Button>
      )}
    </>
  );

  const tool = (
    <>
      <Button
        onClick={() => handleOpenModal(<MyWhiteboard />, "My Whiteboard")}
        variant="flat"
      >
        White Board
      </Button>
      <Button
        onClick={() =>
          handleOpenModal(<AccountingCalculator />, "Accounting Calculator")
        }
        variant="flat"
      >
        Calculator
      </Button>
    </>
  );

  return (
    <>
      <Navbar
        isMenuOpen={isMenuOpen}
        onMenuOpenChange={setIsMenuOpen}
        maxWidth="2xl"
        // isBordered
        isBlurred={false}
        className={`bg-foreground`}
      >
        <NavbarContent className="pr-3" justify="start">
          <NavbarBrand>
            <Link
              href={"/"}
              className="text-3xl font-bold uppercase md:text-4xl"
            >
              <h1>Quize App</h1>
            </Link>
          </NavbarBrand>
        </NavbarContent>

        <NavbarContent
          className="hidden items-center justify-center gap-x-8 font-semibold sm:flex"
          justify="center"
        >
          {Navlist}
          {tool}
        </NavbarContent>
        <NavbarContent
          className="hidden items-center justify-center gap-x-8 font-semibold sm:flex"
          justify="end"
        >
          {authBtn}
        </NavbarContent>
        <NavbarContent className="sm:hidden" justify="end">
          <NavbarMenuToggle
            icon={!isMenuOpen && <AiOutlineMenu className="text-4xl" />}
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
          />
        </NavbarContent>
        <NavbarMenu>
          <NavbarMenuItem className="mt-2 flex flex-col items-center justify-center gap-3 rounded-lg p-1 pt-8 text-center md:hidden">
            {Navlist}
            {tool} {authBtn}
          </NavbarMenuItem>
        </NavbarMenu>
      </Navbar>
      <Modalcomponent
        title={title}
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        Component={ComponentToRender}
        size="3xl"
      />
    </>
  );
}
