"use client";
import { useAxios } from "@/utils/ApiHook";
import {
  Autocomplete,
  AutocompleteItem,
  Button,
  Input,
  Pagination,
  Spinner,
  Table,
  TableBody,
  TableCell,
  TableColumn,
  TableHeader,
  TableRow,
} from "@nextui-org/react";
import { useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { BsSearch } from "react-icons/bs";

const columns = [
  {
    key: "course_name",
    label: "Course Name",
  },
  {
    key: "course_code",
    label: "Course Code",
  },
];

const Courses = () => {
  const router = useRouter();
  const { data, isLoading, ApiRequest } = useAxios();
  const [addData, setAddData] = useState(null);

  const [params, setParams] = useState({
    search: "",
    page: 1,
    pageSize: 10,
  });

  useEffect(() => {
    ApiRequest("/courses/?sortBy=createdAt", "GET", null, params);
  }, [params, addData]);

  const renderCell = React.useCallback((user, columnKey) => {
    const cellValue = user[columnKey];
    switch (columnKey) {
      case "programme":
        return user?.programme?.programme_name;
      default:
        return cellValue;
    }
  }, []);

  const topContent = React.useMemo(() => {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex items-end justify-between gap-3">
          <Input
            className="w-full sm:max-w-[44%]"
            placeholder="Search ..."
            startContent={<BsSearch />}
            onChange={(e) => setParams({ ...params, search: e.target.value })}
          />
          <label htmlFor="page" className="flex items-center">
            Rows per page:
            <select
              id="page"
              value={params.pageSize}
              className="bg-transparent outline-none"
              onChange={(e) =>
                setParams({ ...params, pageSize: e.target.value })
              }
            >
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="15">15</option>
              <option value="all">All</option>
            </select>
          </label>
        </div>
      </div>
    );
  }, [params]);

  return (
    <div className="flex justify-between items- center flex-col h-full">
      <div>
        <AddcourseForm setAddData={setAddData} />
        <Table topContent={topContent} isStriped aria-label="customers table">
          <TableHeader columns={columns}>
            {(column) => (
              <TableColumn key={column.key}>{column.label}</TableColumn>
            )}
          </TableHeader>

          <TableBody
            loadingContent={
              <Spinner size="lg" className="m-8" label="Loading..." />
            }
            isLoading={isLoading}
            items={data ? data.data : []}
          >
            {(item) => (
              <TableRow key={item._id}>
                {(columnKey) => (
                  <TableCell>{renderCell(item, columnKey)}</TableCell>
                )}
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      <div className="flex w-full justify-center py-8 mb-8 lg:mb-20">
        <Pagination
          isCompact
          showControls
          showShadow
          color="secondary"
          page={params.page}
          total={data ? data.pages : 1}
          onChange={(page) => setParams({ ...params, page })}
        />
      </div>
    </div>
  );
};

export default Courses;

const AddcourseForm = ({ setAddData }) => {
  const initial = {
    course_name: "",
    course_code: "",
  };
  const [formData, setFormData] = useState(initial);

  const { data, isLoading, ApiRequest } = useAxios();

  const handleSubmit = (e) => {
    e.preventDefault();
    ApiRequest(`/courses/`, "POST", formData, null);
    setFormData({ formData, ...initial });
  };
  useEffect(() => {
    if (data) {
      setAddData(data);
    }
  }, [data]);

  return (
    <div>
      <form
        onSubmit={handleSubmit}
        className="flex items-center justify-center gap-4 rounded-xl p-4 md:gap-8 bg-foreground mb-8"
      >
        <Input
          label="Course Name "
          isRequired
          onChange={(e) =>
            setFormData({ ...formData, course_name: e.target.value })
          }
          value={formData?.course_name || ""}
        />
        <Input
          label="Course Code "
          isRequired
          onChange={(e) =>
            setFormData({ ...formData, course_code: e.target.value })
          }
          value={formData?.course_code || ""}
        />

        <Button color="primary" type="submit" disabled={isLoading} size="lg">
          Add
        </Button>
      </form>
    </div>
  );
};
