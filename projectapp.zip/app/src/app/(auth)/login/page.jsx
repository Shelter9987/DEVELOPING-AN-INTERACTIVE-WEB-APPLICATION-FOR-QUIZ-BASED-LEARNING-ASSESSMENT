"use client";
import GoogleAuth from "@/components/GoogleAuth";
import { useAxios } from "@/utils/ApiHook";
import { Context } from "@/utils/Context";
import { Button, Divider, Input } from "@nextui-org/react";
import Link from "next/link";
import { useContext, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

const Login = () => {
  const searchParams = useSearchParams();
  const callback = searchParams.get("callback");

  const { setUser, user } = useContext(Context);
  const router = useRouter();

  const { data, isLoading, error, ApiRequest } = useAxios();

  const initial = {
    email: "",
    password: "",
  };
  const [formData, setFormData] = useState(initial);

  const handleSubmit = async (e) => {
    e.preventDefault();
    ApiRequest(`/auth/signin/`, "POST", formData, null);
  };

  useEffect(() => {
    if (data) {
      setUser(data.user);
    }
  }, [data]);

  return (
    <div className=" flex h-full w-full justify-center">
      {/* <div className="hidden lg:block flex-1 bg-primary-light"></div> */}
      <div className="justify- center container flex flex-1 flex-col items-center p-4">
        <form
          onSubmit={handleSubmit}
          className="bg-foreground mx-auto w-full max-w-xl rounded-xl border-2 border-border p-8 backdrop-blur-lg"
        >
          <div className="space-y-8 p-4 text-copy">
            <h2 className="mb-4 text-center text-2xl font-bold md:text-3xl">
              Log in to your account
            </h2>{" "}
            <p className="pt-4 text-center text-error">
              {error ? error.message : ""}
            </p>
            <Input
              label="Email"
              labelPlacement="outside"
              color="primary"
              size="lg"
              type="email"
              isRequired
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
            />
            <Input
              label="Password"
              labelPlacement="outside"
              color="primary"
              size="lg"
              isRequired
              type="password"
              onChange={(e) =>
                setFormData({ ...formData, password: e.target.value })
              }
            />
            <Button
              className="w-full"
              size="lg"
              type="submit"
              color="primary"
              isLoading={isLoading}
            >
              Log in
            </Button>
            <Divider />
            <GoogleAuth />
            {/* <div>
              Dont have an account?
              <Link
                className="text-primary"
                href={`/signup?callback=${callback}`}
              >
                {" "}
                Register
              </Link>
            </div> */}
          </div>
        </form>
      </div>
    </div>
  );
};
export default Login;
