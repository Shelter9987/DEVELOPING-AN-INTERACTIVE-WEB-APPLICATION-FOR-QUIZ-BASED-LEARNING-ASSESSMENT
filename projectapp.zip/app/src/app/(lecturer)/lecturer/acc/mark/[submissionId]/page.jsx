// "use client";
// import { useEffect, useState } from "react";
// import { useParams, useRouter } from "next/navigation";
// import { useAxios } from "@/utils/ApiHook";

// export default function MarkSubmissionPage() {
//   const { data, isLoading, error, ApiRequest } = useAxios();
//   const { data: Mdata, isLoading: Mloading, ApiRequest: Markreq } = useAxios();

//   const { submissionId } = useParams();
//   const router = useRouter();

//   const [scores, setScores] = useState([]);
//   const [remarks, setRemarks] = useState("");

//   useEffect(() => {
//     if (submissionId) {
//       ApiRequest(`/acc/sub/${submissionId}`, "GET", null, null);
//     }
//   }, [submissionId]);

//   useEffect(() => {
//     if (data?.answers?.length > 0) {
//       setScores(data.answers.map(() => 0));
//     }
//   }, [data]);

//   const handleScoreChange = (index, value) => {
//     const num = Number(value);
//     if (!isNaN(num)) {
//       const updated = [...scores];
//       updated[index] = num;
//       setScores(updated);
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const totalScore = scores.reduce((sum, val) => sum + val, 0);
//     await Markreq(
//       `/acc/sub/${submissionId}/mark`,
//       {
//         score: totalScore,
//         remarks,
//       },
//       null,
//     );
//     // router.push("/lecturer/acc/quizzes/");
//   };

//   if (isLoading)
//     return <p className="p-6 text-gray-600">Loading submission...</p>;

//   return (
//     <div className="mx-auto max-w-5xl p-6">
//       <div className="mb-6 border-b pb-4">
//         <h1 className="text-2xl font-bold text-gray-800">📝 Mark Submission</h1>
//         <p className="text-sm text-gray-500">
//           Quiz Title: <span className="font-medium">{data?.quizId?.title}</span>
//         </p>
//       </div>

//       <form onSubmit={handleSubmit} className="space-y-8">
//         {data?.answers?.map((ans, idx) => (
//           <div
//             key={idx}
//             className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm"
//           >
//             <h3 className="mb-2 text-lg font-semibold text-gray-700">
//               Question {idx + 1}
//             </h3>
//             <p className="mb-3 text-sm text-gray-500">
//               <strong>Expected Answer:</strong>{" "}
//               {data.quizId.questions[idx].finalAnswer}
//             </p>

//             <div className="mb-4">
//               <p className="mb-1 text-sm font-medium text-gray-600">
//                 Student Rough Work:
//               </p>
//               <div
//                 className="prose prose-sm max-w-none rounded-md border bg-gray-50 p-3 text-gray-700"
//                 dangerouslySetInnerHTML={{ __html: ans.roughWork }}
//               />
//               <p className="mt-3 text-sm text-gray-600">
//                 <strong>Final Answer:</strong> {ans.finalAnswer}
//               </p>
//             </div>

//             <div className="mt-4">
//               <label className="mb-1 block text-sm font-medium text-gray-700">
//                 Score for this question
//               </label>
//               <input
//                 type="number"
//                 min="0"
//                 max="1"
//                 step="1"
//                 value={scores[idx] ?? 0}
//                 onChange={(e) => handleScoreChange(idx, e.target.value)}
//                 className="w-24 rounded-md border px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                 required
//               />
//             </div>
//           </div>
//         ))}

//         <div className="mt-6">
//           <label className="mb-2 block text-sm font-medium text-gray-700">
//             Remarks
//           </label>
//           <textarea
//             className="w-full rounded-md border px-4 py-3 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
//             rows="4"
//             value={remarks}
//             onChange={(e) => setRemarks(e.target.value)}
//             placeholder="Write remarks for the student..."
//           />
//         </div>

//         <div className="pt-4">
//           <button
//             type="submit"
//             className="rounded-md bg-blue-600 px-6 py-2 font-semibold text-white transition duration-200 hover:bg-blue-700"
//           >
//             ✅ Submit Scores
//           </button>
//         </div>
//       </form>
//     </div>
//   );
// }

"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAxios } from "@/utils/ApiHook";

export default function MarkSubmissionPage() {
  const { data, isLoading, error, ApiRequest } = useAxios();
  const { data: Mdata, isLoading: Mloading, ApiRequest: Markreq } = useAxios();

  const { submissionId } = useParams();
  const router = useRouter();

  const [scores, setScores] = useState([]);
  const [remarks, setRemarks] = useState("");

  // Fetch submission data when component mounts
  useEffect(() => {
    if (submissionId) {
      ApiRequest(`/acc/sub/${submissionId}`, "GET", null, null);
    }
  }, [submissionId]);

  // Initialize scores array when data is loaded
  useEffect(() => {
    if (data?.answers?.length > 0) {
      // Initialize with zeros and the correct length
      setScores(Array(data.answers.length).fill(0));
    }
  }, [data]);

  const handleScoreChange = (index, value) => {
    const num = parseInt(value, 10);
    if (!isNaN(num)) {
      setScores((prevScores) => {
        const updated = [...prevScores];
        updated[index] = num;
        return updated;
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const totalScore = scores.reduce((sum, val) => sum + val, 0);

    try {
      await Markreq(
        `/acc/sub/${submissionId}/mark`,
        "POST", // Added method which was missing
        {
          score: totalScore,
          remarks,
        },
        null,
      );
      // Uncomment this when ready to navigate away
      router.back();
    } catch (error) {
      console.error("Error submitting scores:", error);
    }
  };

  if (isLoading)
    return <p className="p-6 text-gray-600">Loading submission...</p>;

  if (error)
    return (
      <p className="p-6 text-red-600">
        Error loading submission: {error.message}
      </p>
    );

  return (
    <div className="mx-auto max-w-5xl p-6">
      <div className="mb-6 border-b pb-4">
        <h1 className="text-2xl font-bold text-gray-800">📝 Mark Submission</h1>
        <p className="text-sm text-gray-500">
          Quiz Title: <span className="font-medium">{data?.quizId?.title}</span>
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {data?.answers?.map((ans, idx) => (
          <div
            key={idx}
            className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm"
          >
            <h3 className="mb-2 text-lg font-semibold text-gray-700">
              Question {idx + 1}
            </h3>
            <p className="mb-3 text-sm text-gray-500">
              <strong>Expected Answer:</strong>{" "}
              {data.quizId.questions[idx].finalAnswer}
            </p>

            <div className="mb-4">
              <p className="mb-1 text-sm font-medium text-gray-600">
                Student Rough Work:
              </p>
              <div
                className="prose prose-sm max-w-none rounded-md border bg-gray-50 p-3 text-gray-700"
                dangerouslySetInnerHTML={{ __html: ans.roughWork }}
              />
              <p className="mt-3 text-sm text-gray-600">
                <strong>Final Answer:</strong> {ans.finalAnswer}
              </p>
            </div>

            <div className="mt-4">
              <label className="mb-1 block text-sm font-medium text-gray-700">
                Score for this question
              </label>
             

              <input
                type="number"
                min="0"
                max="1"
                step="1"
                value={scores[idx] !== undefined ? scores[idx] : 0}
                onChange={(e) => handleScoreChange(idx, e.target.value)}
                className="w-24 rounded-md border px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
               <h1 className="font-bold italic text-gray-800 py-2">
                Mark 1 for correct and 0 for wrong
              </h1>
            </div>
          </div>
        ))}

        <div className="mt-6">
          <label className="mb-2 block text-sm font-medium text-gray-700">
            Remarks
          </label>
          <textarea
            className="w-full rounded-md border px-4 py-3 text-sm text-gray-700 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows="4"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder="Write remarks for the student..."
          />
        </div>

        <div className="pt-4">
          <button
            type="submit"
            className="rounded-md bg-blue-600 px-6 py-2 font-semibold text-white transition duration-200 hover:bg-blue-700"
            disabled={Mloading}
          >
            {Mloading ? "Submitting..." : "✅ Submit Scores"}
          </button>
        </div>
      </form>
    </div>
  );
}
