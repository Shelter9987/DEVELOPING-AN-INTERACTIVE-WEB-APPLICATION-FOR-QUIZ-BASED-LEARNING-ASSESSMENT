"use client";
import CreateQuize from "@/components/createQuize";
import Modalcomponent from "@/components/Modalcomponent";
import { useAxios } from "@/utils/ApiHook";
import {
  Button,
  Input,
  Pagination,
  Spinner,
  Table,
  TableBody,
  TableCell,
  TableColumn,
  TableHeader,
  TableRow,
} from "@nextui-org/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { BsSearch } from "react-icons/bs";

const Quize = () => {
  const router = useRouter();
  const { data, isLoading, ApiRequest } = useAxios();
  console.log({ data });

  const [params, setParams] = useState({
    search: "",
    page: 1,
    pageSize: 5,
  });

  useEffect(() => {
    ApiRequest("/quize/", "GET", null, params);
  }, [params]);

  const topContent = React.useMemo(() => {
    return (
      <div className="py-4">
        <Input
          className="sm:max-w- [44%] w-full"
          placeholder="Search ..."
          startContent={<BsSearch />}
          onChange={(e) => setParams({ ...params, search: e.target.value })}
        />
      </div>
    );
  }, [params]);

  return (
    <>
      <div className="container mx-auto p-4">
        {topContent}

        <div className="">
          {data &&
            data.map((quiz) => (
              <div
                key={quiz._id}
                className="bg- grid grid-cols-1 gap-4 rounded-lg border bg-foreground p-5 shadow-md transition-shadow duration-200 hover:shadow-lg md:grid-cols-2 lg:grid-cols-4"
              >
                {/* Quiz Title and Description */}
                <div className="space-y-2">
                  <h2 className="text-xl font-bold text-primary">
                    {quiz.title}
                  </h2>
                  <p className="text-muted-foreground line-clamp-2 text-sm">
                    {quiz.desc}
                  </p>
                </div>

                {/* Timing Information */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <circle cx="12" cy="12" r="10" />
                      <polyline points="12 6 12 12 16 14" />
                    </svg>
                    <p className="text-sm">
                      <span className="font-medium">Start:</span>{" "}
                      {new Date(quiz.start_time).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <circle cx="12" cy="12" r="10" />
                      <polyline points="12 6 12 12 8 14" />
                    </svg>
                    <p className="text-sm">
                      <span className="font-medium">End:</span>{" "}
                      {new Date(quiz.end_time).toLocaleString()}
                    </p>
                  </div>
                </div>

                {/* Quiz Stats */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M12 20V10" />
                      <path d="M18 20V4" />
                      <path d="M6 20v-4" />
                    </svg>
                    <p className="text-sm">
                      <span className="font-medium">Marks:</span>{" "}
                      {quiz.marks_allocated}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <circle cx="12" cy="8" r="7" />
                      <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88" />
                    </svg>
                    <p className="text-sm">
                      <span className="font-medium">Questions:</span>{" "}
                      {quiz.questions.length}
                    </p>
                  </div>
                </div>

                {/* Creator and Action Button */}
                <div className="flex flex-col justify-between">
                  <div className="flex items-center gap-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                      <circle cx="12" cy="7" r="4" />
                    </svg>
                    <p className="text-sm">
                      <span className="font-medium">Created By:</span>{" "}
                      {quiz.createdBy.first_name} {quiz.createdBy.last_name}
                    </p>
                  </div>
                  <Link
                    href={`/quizes/${quiz._id}`}
                    className="hover:bg-primary/90 mt-2 flex w-full items-center justify-center rounded-md bg-primary px-4 py-2 font-medium text-primary-foreground transition-colors duration-200"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2"
                    >
                      <polygon points="5 3 19 12 5 21 5 3" />
                    </svg>
                    Attempt Quiz
                  </Link>
                </div>
              </div>
            ))}
        </div>

        <div className="mb-8 flex w-full justify-center py-8 lg:mb-20">
          <Pagination
            isCompact
            showControls
            showShadow
            color="secondary"
            page={params.page}
            total={data ? data.pages : 1}
            onChange={(page) => setParams({ ...params, page })}
          />
        </div>
      </div>
    </>
  );
};

export default Quize;
