"use client";
import { useState } from "react";
import { useAxios } from "@/utils/ApiHook";

export default function CreateQuiz() {
  const { ApiRequest } = useAxios();

  const [title, setTitle] = useState("");
  const [questions, setQuestions] = useState([
    { questionText: "", finalAnswer: "" },
  ]);
  const [message, setMessage] = useState("");

  const addQuestion = () => {
    setQuestions([...questions, { questionText: "", finalAnswer: "" }]);
  };

  const handleQuestionChange = (index, field, value) => {
    const updated = [...questions];
    updated[index][field] = value;
    setQuestions(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await ApiRequest(
      `/acc/quizzes/`,
      "POST",
      {
        title,
        questions,
      },
      null
    );

    setMessage("✅ Quiz created successfully!");
    setTitle("");
    setQuestions([{ questionText: "", finalAnswer: "" }]);
  };

  return (
    <div className="mx-auto max-w-3xl p-6">
      <h1 className="mb-6 text-3xl font-bold text-gray-800">
        Create Accounting Quiz
      </h1>

      {message && (
        <div className="mb-6 rounded-lg bg-green-100 px-4 py-3 text-green-800">
          {message}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700">
            Quiz Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., Trial Balance Practice"
            required
            className="w-full rounded-xl border border-gray-300 p-3 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <div className="space-y-6">
          {questions.map((q, index) => (
            <div
              key={index}
              className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm"
            >
              <h2 className="mb-2 text-lg font-semibold text-gray-700">
                Question {index + 1}
              </h2>

              <textarea
                value={q.questionText}
                onChange={(e) =>
                  handleQuestionChange(index, "questionText", e.target.value)
                }
                placeholder="Enter the question text..."
                rows={3}
                required
                className="w-full rounded-lg border border-gray-300 p-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />

              <input
                type="text"
                value={q.finalAnswer}
                onChange={(e) =>
                  handleQuestionChange(index, "finalAnswer", e.target.value)
                }
                placeholder="Enter correct final answer"
                required
                className="mt-3 w-full rounded-lg border border-gray-300 p-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={addQuestion}
          className="rounded-lg bg-gray-200 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-300 transition"
        >
          + Add Another Question
        </button>

        <div>
          <button
            type="submit"
            className="mt-4 w-full rounded-lg bg-blue-600 px-4 py-3 text-white font-semibold hover:bg-blue-700 transition"
          >
            Submit Quiz
          </button>
        </div>
      </form>
    </div>
  );
}
