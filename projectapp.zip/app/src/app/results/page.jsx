"use client";
import { useEffect, useState } from "react";
import axios from "axios";
import Cookies from "js-cookie";

const StudentResults = () => {
  const [results, setResults] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const limit = 10;

  const storedUser = Cookies.get("qq-user-01") ?? "{}";

  let user = {};
  try {
    user = JSON.parse(storedUser);
  } catch (err) {
    console.warn("Invalid user cookie format.");
  }

  const config = {
    headers: {
      Authorization: `Bearer ${user?.token}`,
    },
  };

  const fetchResults = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/api/results/`,
        {
          params: { page, limit },
          ...config,
        }
      );

      setResults(response.data.results);
      setPagination(response.data.pagination);
    } catch (error) {
      console.error("Failed to fetch results:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResults();
  }, [page]);

  const handlePageChange = (newPage) => {
    if (newPage > 0 && newPage <= pagination.totalPages) {
      setPage(newPage);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h2 className="mb-6 text-3xl font-bold text-gray-800">📊 Your Quiz Results</h2>

      {loading ? (
        <p className="text-gray-500">Loading results...</p>
      ) : results?.length === 0 ? (
        <p className="text-center text-gray-400 italic">No results found.</p>
      ) : (
        <>
          <div className="overflow-x-auto rounded-lg shadow-sm">
            <table className="min-w-full bg-white text-sm text-gray-700 shadow-md rounded-lg overflow-hidden">
              <thead className="bg-gray-100 text-left text-xs font-semibold uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-3">Quiz Title</th>
                  <th className="px-6 py-3">Score</th>
                  <th className="px-6 py-3">Submitted At</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {results.map((result) => (
                  <tr
                    key={result._id}
                    className="hover:bg-gray-50 transition-colors duration-150"
                  >
                    <td className="px-6 py-4">
                      {result.quizId?.title || "Untitled Quiz"}
                    </td>
                    <td className="px-6 py-4 font-medium">{result.score}%</td>
                    <td className="px-6 py-4">
                      {new Date(result.createdAt).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-6 flex items-center justify-between">
            <button
              className="rounded-md bg-blue-600 px-4 py-2 text-white shadow-sm transition hover:bg-blue-700 disabled:opacity-50"
              onClick={() => handlePageChange(page - 1)}
              disabled={page === 1}
            >
              ← Previous
            </button>
            <span className="text-gray-600">
              Page <strong>{pagination.page}</strong> of{" "}
              <strong>{pagination.totalPages}</strong>
            </span>
            <button
              className="rounded-md bg-blue-600 px-4 py-2 text-white shadow-sm transition hover:bg-blue-700 disabled:opacity-50"
              onClick={() => handlePageChange(page + 1)}
              disabled={page === pagination.totalPages}
            >
              Next →
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default StudentResults;
