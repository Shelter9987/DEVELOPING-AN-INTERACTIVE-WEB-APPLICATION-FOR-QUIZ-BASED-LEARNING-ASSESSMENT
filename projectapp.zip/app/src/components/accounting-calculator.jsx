"use client"

import { Button, Card, CardBody, Input, Tab, Tabs, Textarea } from "@nextui-org/react"
import { BarChart, Calculator, DollarSign, LineChart, Percent, TrendingDown } from "lucide-react"
import { useState } from "react"

export default function AccountingCalculator() {
  // State for calculator display
  const [display, setDisplay] = useState("0")
  const [currentOperation, setCurrentOperation] = useState(null)
  const [previousValue, setPreviousValue] = useState(null)
  const [resetDisplay, setResetDisplay] = useState(false)

  // State for workspace
  const [workspace, setWorkspace] = useState("")

  // State for specialized calculators
  const [taxRate, setTaxRate] = useState(20)
  const [amount, setAmount] = useState(0)
  const [assetValue, setAssetValue] = useState(10000)
  const [salvageValue, setSalvageValue] = useState(1000)
  const [usefulLife, setUsefulLife] = useState(5)
  const [depreciationRate, setDepreciationRate] = useState(20)
  const [fixedCosts, setFixedCosts] = useState(50000)
  const [unitPrice, setUnitPrice] = useState(100)
  const [unitVariableCost, setUnitVariableCost] = useState(60)
  const [principal, setPrincipal] = useState(10000)
  const [interestRate, setInterestRate] = useState(5)
  const [timePeriod, setTimePeriod] = useState(3)

  // Tab state
  const [selectedTab, setSelectedTab] = useState("basic")

  // Results state
  const [result, setResult] = useState(null)

  // Handle number input for basic calculator
  const handleNumberClick = (number) => {
    if (display === "0" || resetDisplay) {
      setDisplay(number.toString())
      setResetDisplay(false)
    } else {
      setDisplay(display + number.toString())
    }
  }

  // Handle operation for basic calculator
  const handleOperationClick = (operation) => {
    if (previousValue === null) {
      setPreviousValue(Number.parseFloat(display))
    } else if (currentOperation) {
      const result = performCalculation()
      setPreviousValue(result)
      setDisplay(result.toString())
    }

    setCurrentOperation(operation)
    setResetDisplay(true)
  }

  // Perform calculation based on operation
  const performCalculation = () => {
    const current = Number.parseFloat(display)
    const previous = previousValue

    switch (currentOperation) {
      case "+":
        return previous + current
      case "-":
        return previous - current
      case "*":
        return previous * current
      case "/":
        return previous / current
      default:
        return current
    }
  }

  // Handle equals button
  const handleEquals = () => {
    if (currentOperation && previousValue !== null) {
      const result = performCalculation()
      setDisplay(result.toString())
      setCurrentOperation(null)
      setPreviousValue(null)

      // Add calculation to workspace
      addToWorkspace(`${previousValue} ${currentOperation} ${Number.parseFloat(display)} = ${result}`)
    }
  }

  // Clear calculator
  const handleClear = () => {
    setDisplay("0")
    setCurrentOperation(null)
    setPreviousValue(null)
    setResetDisplay(false)
  }

  // Add to workspace
  const addToWorkspace = (text) => {
    setWorkspace(workspace + (workspace ? "\n" : "") + text)
  }

  // Calculate profit and loss
  const calculateProfitLoss = () => {
    const revenue = Number.parseFloat(document.getElementById("revenue").value || 0)
    const expenses = Number.parseFloat(document.getElementById("expenses").value || 0)
    const profit = revenue - expenses
    setResult(`Profit/Loss: $${profit.toFixed(2)}`)
    addToWorkspace(`Profit/Loss: Revenue $${revenue} - Expenses $${expenses} = $${profit.toFixed(2)}`)
  }

  // Calculate tax
  const calculateTax = () => {
    const taxAmount = (amount * taxRate) / 100
    const total = amount + taxAmount
    setResult(`Tax: $${taxAmount.toFixed(2)}, Total: $${total.toFixed(2)}`)
    addToWorkspace(
      `Tax Calculation: Amount $${amount} × Rate ${taxRate}% = $${taxAmount.toFixed(2)}, Total: $${total.toFixed(2)}`,
    )
  }

  // Calculate straight-line depreciation
  const calculateStraightLineDepreciation = () => {
    const annualDepreciation = (assetValue - salvageValue) / usefulLife
    const depreciationSchedule = []

    let remainingValue = assetValue
    for (let year = 1; year <= usefulLife; year++) {
      remainingValue -= annualDepreciation
      depreciationSchedule.push({
        year,
        depreciation: annualDepreciation,
        remainingValue,
      })
    }

    setResult(`Annual Depreciation: $${annualDepreciation.toFixed(2)}`)
    addToWorkspace(
      `Straight-Line Depreciation: ($${assetValue} - $${salvageValue}) / ${usefulLife} years = $${annualDepreciation.toFixed(2)}/year`,
    )
  }

  // Calculate reducing balance depreciation
  const calculateReducingBalanceDepreciation = () => {
    const depreciationSchedule = []
    let bookValue = assetValue

    for (let year = 1; year <= usefulLife; year++) {
      const yearDepreciation = (bookValue * depreciationRate) / 100
      bookValue -= yearDepreciation

      depreciationSchedule.push({
        year,
        depreciation: yearDepreciation,
        bookValue,
      })
    }

    setResult(`First Year Depreciation: $${depreciationSchedule[0].depreciation.toFixed(2)}`)
    addToWorkspace(
      `Reducing Balance Depreciation: Year 1 = $${assetValue} × ${depreciationRate}% = $${depreciationSchedule[0].depreciation.toFixed(2)}`,
    )
  }

  // Calculate break-even point
  const calculateBreakEven = () => {
    const contributionMargin = unitPrice - unitVariableCost
    const breakEvenUnits = fixedCosts / contributionMargin
    const breakEvenRevenue = breakEvenUnits * unitPrice

    setResult(`Break-even Point: ${breakEvenUnits.toFixed(0)} units, Revenue: $${breakEvenRevenue.toFixed(2)}`)
    addToWorkspace(
      `Break-even Analysis: Fixed Costs $${fixedCosts} ÷ Contribution Margin $${contributionMargin} = ${breakEvenUnits.toFixed(0)} units`,
    )
  }

  // Calculate simple interest
  const calculateSimpleInterest = () => {
    const interest = (principal * interestRate * timePeriod) / 100
    const total = principal + interest

    setResult(`Simple Interest: $${interest.toFixed(2)}, Total: $${total.toFixed(2)}`)
    addToWorkspace(`Simple Interest: $${principal} × ${interestRate}% × ${timePeriod} years = $${interest.toFixed(2)}`)
  }

  // Calculate compound interest
  const calculateCompoundInterest = () => {
    const total = principal * Math.pow(1 + interestRate / 100, timePeriod)
    const interest = total - principal

    setResult(`Compound Interest: $${interest.toFixed(2)}, Total: $${total.toFixed(2)}`)
    addToWorkspace(`Compound Interest: $${principal} × (1 + ${interestRate}%)^${timePeriod} = $${total.toFixed(2)}`)
  }

  // Clear workspace
  const clearWorkspace = () => {
    setWorkspace("")
  }

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6 text-center">Accounting Calculator</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Left column - Calculator */}
        <div className="md:col-span-2">
          <Tabs
            selectedKey={selectedTab}
            onSelectionChange={setSelectedTab}
            aria-label="Calculator Functions"
            className="w-full"
            variant="underlined"
          >
            <Tab
              key="basic"
              title={
                <div className="flex items-center gap-1">
                  <Calculator className="h-4 w-4" />
                  <span className="hidden md:inline">Basic</span>
                </div>
              }
            >
              <Card>
                <CardBody className="pt-6">
                  <div className="mb-4">
                    <Input value={display} readOnly className="text-right text-2xl h-14" size="lg" />
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    <Button color="danger" variant="flat" onClick={() => handleClear()}>
                      C
                    </Button>
                    <Button color="default" variant="flat" onClick={() => setDisplay(display.slice(0, -1) || "0")}>
                      ←
                    </Button>
                    <Button color="default" variant="flat" onClick={() => handleNumberClick(".")}>
                      .
                    </Button>
                    <Button color="primary" variant="flat" onClick={() => handleOperationClick("/")}>
                      /
                    </Button>

                    <Button color="default" variant="flat" onClick={() => handleNumberClick(7)}>
                      7
                    </Button>
                    <Button color="default" variant="flat" onClick={() => handleNumberClick(8)}>
                      8
                    </Button>
                    <Button color="default" variant="flat" onClick={() => handleNumberClick(9)}>
                      9
                    </Button>
                    <Button color="primary" variant="flat" onClick={() => handleOperationClick("*")}>
                      ×
                    </Button>

                    <Button color="default" variant="flat" onClick={() => handleNumberClick(4)}>
                      4
                    </Button>
                    <Button color="default" variant="flat" onClick={() => handleNumberClick(5)}>
                      5
                    </Button>
                    <Button color="default" variant="flat" onClick={() => handleNumberClick(6)}>
                      6
                    </Button>
                    <Button color="primary" variant="flat" onClick={() => handleOperationClick("-")}>
                      -
                    </Button>

                    <Button color="default" variant="flat" onClick={() => handleNumberClick(1)}>
                      1
                    </Button>
                    <Button color="default" variant="flat" onClick={() => handleNumberClick(2)}>
                      2
                    </Button>
                    <Button color="default" variant="flat" onClick={() => handleNumberClick(3)}>
                      3
                    </Button>
                    <Button color="primary" variant="flat" onClick={() => handleOperationClick("+")}>
                      +
                    </Button>

                    <Button color="default" variant="flat" onClick={() => handleNumberClick(0)} className="col-span-2">
                      0
                    </Button>
                    <Button
                      color="default"
                      variant="flat"
                      onClick={() => setDisplay((Number.parseFloat(display) * -1).toString())}
                    >
                      +/-
                    </Button>
                    <Button color="success" onClick={() => handleEquals()}>
                      =
                    </Button>
                  </div>
                </CardBody>
              </Card>
            </Tab>

            <Tab
              key="profit"
              title={
                <div className="flex items-center gap-1">
                  <DollarSign className="h-4 w-4" />
                  <span className="hidden md:inline">Profit/Loss</span>
                </div>
              }
            >
              <Card>
                <CardBody className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <Input id="revenue" type="number" label="Revenue ($)" placeholder="Enter revenue" />
                  </div>

                  <div className="space-y-2">
                    <Input id="expenses" type="number" label="Expenses ($)" placeholder="Enter expenses" />
                  </div>

                  <Button color="primary" onClick={calculateProfitLoss} className="w-full">
                    Calculate Profit/Loss
                  </Button>

                  {result && (
                    <div className="p-3 bg-gray-100 text-copy rounded-md mt-4">
                      <p className="font-medium">{result}</p>
                    </div>
                  )}
                </CardBody>
              </Card>
            </Tab>

            <Tab
              key="tax"
              title={
                <div className="flex items-center gap-1">
                  <Percent className="h-4 w-4" />
                  <span className="hidden md:inline">Tax</span>
                </div>
              }
            >
              <Card>
                <CardBody className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <Input
                      id="amount"
                      type="number"
                      label="Amount ($)"
                      value={amount}
                      onChange={(e) => setAmount(Number.parseFloat(e.target.value) || 0)}
                      placeholder="Enter amount"
                    />
                  </div>

                  <div className="space-y-2">
                    <Input
                      id="taxRate"
                      type="number"
                      label="Tax Rate (%)"
                      value={taxRate}
                      onChange={(e) => setTaxRate(Number.parseFloat(e.target.value) || 0)}
                      placeholder="Enter tax rate"
                    />
                  </div>

                  <Button color="primary" onClick={calculateTax} className="w-full">
                    Calculate Tax
                  </Button>

                  {result && (
                    <div className="p-3 bg-gray-100 text-copy rounded-md mt-4">
                      <p className="font-medium">{result}</p>
                    </div>
                  )}
                </CardBody>
              </Card>
            </Tab>

            <Tab
              key="depreciation"
              title={
                <div className="flex items-center gap-1">
                  <TrendingDown className="h-4 w-4" />
                  <span className="hidden md:inline">Depreciation</span>
                </div>
              }
            >
              <Card>
                <CardBody className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <Input
                      id="assetValue"
                      type="number"
                      label="Asset Value ($)"
                      value={assetValue}
                      onChange={(e) => setAssetValue(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Input
                      id="salvageValue"
                      type="number"
                      label="Salvage Value ($)"
                      value={salvageValue}
                      onChange={(e) => setSalvageValue(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Input
                      id="usefulLife"
                      type="number"
                      label="Useful Life (years)"
                      value={usefulLife}
                      onChange={(e) => setUsefulLife(Number.parseInt(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Input
                      id="depreciationRate"
                      type="number"
                      label="Depreciation Rate (% for reducing balance)"
                      value={depreciationRate}
                      onChange={(e) => setDepreciationRate(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button color="primary" onClick={calculateStraightLineDepreciation}>
                      Straight-Line
                    </Button>
                    <Button color="primary" onClick={calculateReducingBalanceDepreciation}>
                      Reducing Balance
                    </Button>
                  </div>

                  {result && (
                    <div className="p-3 bg-gray-100 text-copy rounded-md mt-4">
                      <p className="font-medium">{result}</p>
                    </div>
                  )}
                </CardBody>
              </Card>
            </Tab>

            <Tab
              key="breakeven"
              title={
                <div className="flex items-center gap-1">
                  <BarChart className="h-4 w-4" />
                  <span className="hidden md:inline">Break-even</span>
                </div>
              }
            >
              <Card>
                <CardBody className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <Input
                      id="fixedCosts"
                      type="number"
                      label="Fixed Costs ($)"
                      value={fixedCosts}
                      onChange={(e) => setFixedCosts(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Input
                      id="unitPrice"
                      type="number"
                      label="Unit Price ($)"
                      value={unitPrice}
                      onChange={(e) => setUnitPrice(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Input
                      id="unitVariableCost"
                      type="number"
                      label="Unit Variable Cost ($)"
                      value={unitVariableCost}
                      onChange={(e) => setUnitVariableCost(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>

                  <Button color="primary" onClick={calculateBreakEven} className="w-full">
                    Calculate Break-even
                  </Button>

                  {result && (
                    <div className="p-3 bg-gray-100 text-copy rounded-md mt-4">
                      <p className="font-medium">{result}</p>
                    </div>
                  )}
                </CardBody>
              </Card>
            </Tab>

            <Tab
              key="interest"
              title={
                <div className="flex items-center gap-1">
                  <LineChart className="h-4 w-4" />
                  <span className="hidden md:inline">Interest</span>
                </div>
              }
            >
              <Card>
                <CardBody className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <Input
                      id="principal"
                      type="number"
                      label="Principal ($)"
                      value={principal}
                      onChange={(e) => setPrincipal(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Input
                      id="interestRate"
                      type="number"
                      label="Interest Rate (%)"
                      value={interestRate}
                      onChange={(e) => setInterestRate(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Input
                      id="timePeriod"
                      type="number"
                      label="Time Period (years)"
                      value={timePeriod}
                      onChange={(e) => setTimePeriod(Number.parseInt(e.target.value) || 0)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button color="primary" onClick={calculateSimpleInterest}>
                      Simple Interest
                    </Button>
                    <Button color="primary" onClick={calculateCompoundInterest}>
                      Compound Interest
                    </Button>
                  </div>

                  {result && (
                    <div className="p-3 bg-gray-100 text-copy rounded-md mt-4">
                      <p className="font-medium">{result}</p>
                    </div>
                  )}
                </CardBody>
              </Card>
            </Tab>
          </Tabs>
        </div>

        {/* Right column - Workspace */}
        <div className="md:col-span-1">
          <Card className="h-full">
            <CardBody className="pt-6">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">Workspace</h3>
                <Button color="default" size="sm" variant="light" onClick={clearWorkspace}>
                  Clear
                </Button>
              </div>
              <Textarea
                value={workspace}
                onChange={(e) => setWorkspace(e.target.value)}
                className="h-[400px] font-mono text-sm"
                placeholder="Your calculations will appear here..."
                minRows={10}
              />
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  )
}

