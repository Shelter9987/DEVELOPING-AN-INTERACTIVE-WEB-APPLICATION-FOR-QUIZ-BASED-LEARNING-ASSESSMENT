import {
  Button,
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
} from "@nextui-org/react";

const Modalcomponent = ({
  isOpen,
  setIsOpen,
  Component,
  title,
  size = "5xl",
}) => {
  return (
    <div>
      {/* <Button onPress={() => setIsOpen(!isOpen)}>Open Modal</Button> */}
      <Modal
        backdrop="blur"
        isDismissable={false}
        size={size}
        isOpen={isOpen}
        // scrollBehavior="inside"
        onOpenChange={() => setIsOpen(!isOpen)}
      >
        <ModalContent>
          <>
            <ModalHeader className="flex justify-center items-center">
              <h1 className="text-center text-xl font-bold uppercase">
                {title}
              </h1>
            </ModalHeader>
            <ModalBody>{Component && Component}</ModalBody>
            <ModalFooter>
              <Button
                color="danger"
                variant="light"
                onPress={() => setIsOpen(!isOpen)}
              >
                Close
              </Button>
              {/* <Button color="primary" onPress={() => setIsOpen(!isOpen)}>
                Action
              </Button> */}
            </ModalFooter>
          </>
        </ModalContent>
      </Modal>
    </div>
  );
};

export default Modalcomponent;
