"use client";
import Modalcomponent from "@/components/Modalcomponent";
import QuestionsCard from "@/components/QuestionsCard";
import { useAxios } from "@/utils/ApiHook";
import {
  Autocomplete,
  AutocompleteItem,
  Button,
  Input,
  Pagination,
  Select,
  SelectItem,
} from "@nextui-org/react";
import { useEffect, useState } from "react";
import { BsSearch } from "react-icons/bs";
import QuestionForm from "./create/page";

const Question = () => {
  const { data, isLoading, ApiRequest } = useAxios();

  const [isOpen, setIsOpen] = useState(false);
  const [ComponentToRender, setComponentToRender] = useState(null);
  const [modaltitle, setModalTitle] = useState("");

  const handleOpenModal = (Component, title) => {
    setModalTitle(title);
    setComponentToRender(() => Component);
    setIsOpen(true);
  };

  // console.log("====================================");
  // console.log(data);
  // console.log("====================================");

  const {
    data: coursesData,
    isLoading: coursesLoading,
    ApiRequest: getCourse,
  } = useAxios();

  const [params, setParams] = useState({
    search: "",
    courseId: "",
    page: 1,
    pageSize: 10,
  });

  useEffect(() => {
    ApiRequest("/questions/?sortBy=createdAt", "GET", null, params);
  }, [params]);

  useEffect(() => {
    getCourse("/courses/?sortBy=createdAt&pageSize=all", "GET", null, null);
  }, []);

  const topContent = (
    <div className="mb-8 flex items-end justify-between gap-5 rounded-lg bg-foreground p-4 shadow">
      <Input
        size="lg"
        placeholder="Search ..."
        startContent={<BsSearch />}
        color="primary"
        onChange={(e) => setParams({ ...params, search: e.target.value })}
      />
      <Autocomplete
        size="sm"
        name="courseId"
        color="primary"
        isRequired
        label="Select Course"
        selectedKey={params?.courseId}
        onSelectionChange={(newCourseId) =>
          setParams((prev) => ({ ...prev, courseId: newCourseId }))
        }
      >
        {coursesData?.data?.map((item, i) => (
          <AutocompleteItem key={item._id}>
            {item.course_name + " " + item.course_code}
          </AutocompleteItem>
        ))}
      </Autocomplete>{" "}
      <div>
        <Button
          color="primary"
          size="lg"
          onClick={() =>
            handleOpenModal(
              <QuestionForm />,
              "Add Question",
            )
          }
        >
          Add
        </Button>
      </div>
    </div>
  );

  return (
    <>
      <div className="items- center flex h-full flex-col justify-between">
        {topContent}

        {data && (
          <div className="space-y-4">
            {data?.data.map((question, index) => (
              <QuestionsCard question={question} key={index} />
            ))}
          </div>
        )}
        <div className="mb-8 flex w-full justify-center py-8 lg:mb-20">
          <Pagination
            isCompact
            showControls
            showShadow
            color="secondary"
            page={params.page}
            total={data ? data.pages : 1}
            onChange={(page) => setParams({ ...params, page })}
          />
        </div>
      </div>
      <Modalcomponent
        title={modaltitle}
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        Component={ComponentToRender}
        size="3xl"
      />
    </>
  );
};

export default Question;
