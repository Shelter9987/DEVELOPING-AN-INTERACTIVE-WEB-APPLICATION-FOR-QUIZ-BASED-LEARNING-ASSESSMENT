import Hero from "@/components/Hero";

const Home = () => {
  return (
    <>
      {/* <Hero /> */}
      <div className="min-h-screen bg-gray-100">
        {/* Hero Section */}
        <section className="bg-blue-600 py-20 text-white">
          <div className="container mx-auto px-4 text-center">
            <h1 className="mb-4 text-5xl font-bold">
              Empower Your Classroom with Easy Quizzes
            </h1>
            <p className="mb-6 text-lg">
              A platform where lecturers create quizzes and students answer them
              effortlessly.
            </p>
            <button className="rounded-lg bg-white px-6 py-3 font-semibold text-blue-600 shadow hover:bg-gray-100">
              Get Started
            </button>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="bg-white py-16">
          <div className="container mx-auto px-4">
            <h2 className="mb-8 text-center text-3xl font-bold">
              How It Works
            </h2>
            <div className="grid gap-8 md:grid-cols-3">
              <div className="p-6 text-center">
                <h3 className="mb-2 text-xl font-semibold">Step 1</h3>
                <p>Create an account as a lecturer or student.</p>
              </div>
              <div className="p-6 text-center">
                <h3 className="mb-2 text-xl font-semibold">Step 2</h3>
                <p>Lecturers create quizzes or assignments.</p>
              </div>
              <div className="p-6 text-center">
                <h3 className="mb-2 text-xl font-semibold">Step 3</h3>
                <p>Students answer quizzes and get instant results.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="bg-gray-100 py-16">
          <div className="container mx-auto px-4">
            <h2 className="mb-8 text-center text-3xl font-bold">Features</h2>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="rounded-lg bg-white p-6 shadow">
                <h3 className="mb-2 text-xl font-semibold">Create Quizzes</h3>
                <p>
                  Easily create multiple-choice, true/false, or essay-type
                  quizzes.
                </p>
              </div>
              <div className="rounded-lg bg-white p-6 shadow">
                <h3 className="mb-2 text-xl font-semibold">Instant Grading</h3>
                <p>
                  Automatically grade quizzes and provide immediate feedback.
                </p>
              </div>
              <div className="rounded-lg bg-white p-6 shadow">
                <h3 className="mb-2 text-xl font-semibold">
                  Progress Tracking
                </h3>
                <p>
                  Track student performance over time with detailed analytics.
                </p>
              </div>
              <div className="rounded-lg bg-white p-6 shadow">
                <h3 className="mb-2 text-xl font-semibold">Assignments</h3>
                <p>Allow students to complete and submit assignments online.</p>
              </div>
              <div className="rounded-lg bg-white p-6 shadow">
                <h3 className="mb-2 text-xl font-semibold">Secure Platform</h3>
                <p>
                  Ensure data privacy and prevent cheating with robust security.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="bg-blue-600 py-16 text-white">
          <div className="container mx-auto px-4">
            <h2 className="mb-8 text-center text-3xl font-bold">
              Why Use Our Platform?
            </h2>
            <div className="grid gap-8 md:grid-cols-2">
              <div className="p-6">
                <h3 className="mb-2 text-xl font-semibold">For Lecturers</h3>
                <p>
                  Create quizzes quickly, grade automatically, and save time.
                </p>
              </div>
              <div className="p-6">
                <h3 className="mb-2 text-xl font-semibold">For Students</h3>
                <p>
                  Access quizzes easily, get instant results, and track
                  progress.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call-to-Action Section */}
        <section className="bg-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="mb-4 text-3xl font-bold">
              Start Conducting Quizzes Today
            </h2>
            <p className="mb-6 text-lg">
              Join our platform now and make learning and testing easier than
              ever.
            </p>
            <button className="rounded-lg bg-blue-600 px-6 py-3 font-semibold text-white shadow hover:bg-blue-700">
              Get Started Now
            </button>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;
