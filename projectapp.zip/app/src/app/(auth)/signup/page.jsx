"use client";

import GoogleAuth from "@/components/GoogleAuth";
import { useAxios } from "@/utils/ApiHook";
import { Button, Divider, Input } from "@nextui-org/react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";

const Signup = () => {
  const searchParams = useSearchParams();

  const callback = searchParams.get("callback");

  const { data, isLoading, error, ApiRequest } = useAxios();

  const initial = {
    first_name: "",
    last_name: "",
    email: "",
    password: "",
  };

  const router = useRouter();
  const [formData, setFormData] = useState(initial);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await ApiRequest(`/auth/signup/`, "POST", formData, null);
  };

  useEffect(() => {
    if (data) {
      if (callback) {
        router.push(callback);
      } else {
        router.push("/company");
      }
    }
  }, [data, callback, router]);

  useEffect(() => {
    router.push("/");
  }, []);

  const isFormValid =
    formData.first_name &&
    formData.last_name &&
    formData.email &&
    formData.password;

  return (
    <div className="flex h-full w-full items-center justify-center">
      <div className="container flex flex-1 flex-col items-center bg-background p-4">
        <form
          onSubmit={handleSubmit}
          className="mx-auto w-full max-w-xl rounded-xl border-2 border-border bg-white/10 p-8 backdrop-blur-lg"
        >
          <div className="space-y-8 p-4 text-copy">
            <h2 className="text-center text-2xl font-bold md:text-3xl">
              Sign up for an account
            </h2>
            <p className="text-center text-error">
              {error
                ? error.response?.data?.message ||
                  "An error occurred, please try again."
                : ""}
            </p>
            <Input
              label="First Name"
              labelPlacement="outside"
              color="primary"
              size="lg"
              isRequired
              onChange={(e) =>
                setFormData({ ...formData, first_name: e.target.value })
              }
            />
            <Input
              label="Last name"
              labelPlacement="outside"
              color="primary"
              size="lg"
              isRequired
              onChange={(e) =>
                setFormData({ ...formData, last_name: e.target.value })
              }
            />
            <Input
              label="Email"
              labelPlacement="outside"
              color="primary"
              size="lg"
              type="email"
              isRequired
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
            />
            <Input
              label="Password"
              labelPlacement="outside"
              color="primary"
              size="lg"
              isRequired
              type="password"
              onChange={(e) =>
                setFormData({ ...formData, password: e.target.value })
              }
            />
            <Button
              className="w-full"
              size="lg"
              type="submit"
              color="primary"
              isLoading={isLoading}
              disabled={!isFormValid}
            >
              {isLoading ? "Signing up..." : "Sign up"}
            </Button>
            <Divider />
            <GoogleAuth />
            <div>
              Already have an account?
              <Link
                className="text-primary"
                href={`/login?callback=${callback}`}
              >
                {" "}
                Login
              </Link>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Signup;
