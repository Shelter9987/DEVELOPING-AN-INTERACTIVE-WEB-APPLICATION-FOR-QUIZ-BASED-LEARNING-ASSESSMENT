"use client";
import { useAxios } from "@/utils/ApiHook";
import { Context } from "@/utils/Context";
import { useGoogleLogin } from "@react-oauth/google";
import { useRouter } from "next/navigation";
import { useContext, useEffect, useState } from "react";
import { BsGoogle } from "react-icons/bs";

import { Button } from "@nextui-org/react";

const GoogleAuth = () => {
  const { data, error, isLoading, ApiRequest } = useAxios();
  const router = useRouter();

  const { setUser } = useContext(Context);
  const [googleUser, setGoogleUser] = useState(null);

  const login = useGoogleLogin({
    onSuccess: (codeResponse) => setGoogleUser(codeResponse),
    onError: (error) => console.log("Login Failed:", error),
  });

  useEffect(() => {
    handleSubmit();
  }, [googleUser]);

  const handleSubmit = async () => {
    if (!googleUser) {
      return;
    }

    ApiRequest(
      `/auth/google/`,
      "POST",
      {
        idToken: googleUser.access_token,
      },
      null,
    );
  };

  useEffect(() => {
    if (data) {
      setUser(data.data);
      if (data.data.role === "lecturer") {
        router.push("/lecturer");
      } else {
        router.push("/");
      }
    }
  }, [data]);

  return (
    <Button
      isLoading={isLoading}
      startContent={<BsGoogle />}
      // color="primary"
      size="lg"
      variant="ghost"
      className="w-full"
      onClick={() => login()}
    >
      Sign in with Google
    </Button>
  );
};
export default GoogleAuth;
