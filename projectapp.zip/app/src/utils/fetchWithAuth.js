import { cookies } from "next/headers";

export const fetchWithAuth = async (endpoint, { method = "GET", body = null } = {}) => {
  try {
    const cookieStore = cookies();
    const userCookie = cookieStore.get("qq-user-01");
    const profile = JSON.parse(userCookie?.value || "{}");
    const token = profile?.token;

    if (!token) {
      throw new Error("Authentication token is missing");
    }

    const headers = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    };

    const options = {
      method,
      headers,
      cache: "no-store",
    };

    if (body) {
      options.body = JSON.stringify(body);
    }

    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}${endpoint}`, options);

    if (!res.ok) {
      throw new Error(`Error fetching data: ${res.statusText}`);
    }

    const data = await res.json();
    return data;
  } catch (error) {
    console.error("Error in fetchWithAuth:", error);
    throw error;
  }
};
