"use client";
import { useAxios } from "@/utils/ApiHook";
import {
  Autocomplete,
  AutocompleteItem,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
} from "@nextui-org/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function QuestionForm({ question }) {
  const router = useRouter();
  const initial = {
    courseId: "",
    questionText: "",
    options: { A: "", B: "", C: "", D: "" },
    correctAnswer: "",
    standard: "",
  };
  const [formData, setFormData] = useState(question ? question : initial);
  const [isEditMode, setIsEditMode] = useState(Boolean(question));

  const { data, isLoading, ApiRequest } = useAxios();

  const {
    data: coursesData,
    isLoading: coursesLoading,
    ApiRequest: getCourse,
  } = useAxios();

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.startsWith("options.")) {
      const optionKey = name.split(".")[1];
      setFormData((prevData) => ({
        ...prevData,
        options: { ...prevData.options, [optionKey]: value },
      }));
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (isEditMode) {
      // Update an existing quiz
      await ApiRequest(
        `/question/update/${formData._id}/`,
        "PUT",
        formData,
        null,
      );
    } else {
      // Create a new quiz
      await ApiRequest("/question/create", "POST", formData, null);
    }
  };

  useEffect(() => {
    getCourse("/courses/?sortBy=createdAt&pageSize=all", "GET", null, null);
  }, []);

  useEffect(() => {
    if (data) {
      if (!isEditMode) {
        setFormData(initial);
      }
    }
    router.refresh();
  }, [data]);

  return (
    <form
      onSubmit={handleSubmit}
      className="mb-8 flex flex-col items-center justify-center gap-4 rounded-xl bg-foreground p-4 px-8 md:gap-8"
    >
      <h2 className="text-center text-2xl font-bold">
        {isEditMode ? "Update question" : "Create a new question"}
      </h2>
      <Autocomplete
        name="courseId"
        color="primary"
        isRequired
        label="Select Course"
        onChange={handleChange}
        selectedKey={formData?.courseId}
        onSelectionChange={(newCourseId) =>
          setFormData((prev) => ({ ...prev, courseId: newCourseId }))
        }
      >
        {coursesData?.data?.map((item, i) => (
          <AutocompleteItem key={item._id}>
            {item.course_name + " " + item.course_code}
          </AutocompleteItem>
        ))}
      </Autocomplete>{" "}
      <Textarea
        color="primary"
        label="Question Text:"
        isRequired
        name="questionText"
        value={formData.questionText}
        onChange={handleChange}
      />
      <div className="grid w-full gap-4 md:grid-cols-2 lg:grid-cols-4">
        {["A", "B", "C", "D"].map((option) => (
          <Input
            color="primary"
            label={`Options.${option}`}
            isRequired
            key={option}
            name={`options.${option}`}
            value={formData.options[option]}
            onChange={handleChange}
          />
        ))}
      </div>
      <Select
        color="primary"
        label=" Correct Answer:"
        isRequired
        name="correctAnswer"
        value={formData.correctAnswer}
        onChange={handleChange}
      >
        {["A", "B", "C", "D"].map((op) => (
          <SelectItem key={op} value={op}>
            {op}
          </SelectItem>
        ))}
      </Select>
      <Select
        color="primary"
        label="Standard"
        name="standard"
        value={formData.standard}
        onChange={handleChange}
      >
        {["below", "standard", "above", "hard"].map((op) => (
          <SelectItem key={op} value={op}>
            {op}
          </SelectItem>
        ))}
      </Select>
      <Button
        isLoading={isLoading}
        className="w-full"
        color="primary"
        type="submit"
      >
        Submit Question
      </Button>
    </form>
  );
}
