// "use client";

// import dynamic from "next/dynamic";
// import "react-quill/dist/quill.snow.css";
// import "katex/dist/katex.min.css";

// const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });

// const modules = {
//   toolbar: [
//     ["bold", "italic", "underline"],
//     [{ list: "ordered" }, { list: "bullet" }],
//     ["link", "image"],
//     ["formula"]  // Enables the KaTeX formula button
//   ]
// };

// export default function QuillMathEditor({ value, onChange }) {
//   return (
//     <ReactQuill
//       value={value}
//       onChange={onChange}
//       modules={modules}
//       theme="snow"
//     />
//   );
// }


"use client";

import { useEffect } from "react";
import dynamic from "next/dynamic";
import "react-quill/dist/quill.snow.css";
import "katex/dist/katex.min.css";

// Dynamically import ReactQuill to avoid SSR issues
const ReactQuill = dynamic(() => import("react-quill"), { 
  ssr: false,
  loading: () => <div className="h-64 border rounded-md bg-gray-50 animate-pulse" />
});

const MathQuillEditor = ({ value, onChange }) => {
  // Load KaTeX and Quill formula module on the client side only
  useEffect(() => {
    if (typeof window !== "undefined") {
      // This ensures KaTeX is available when Quill tries to render formulas
      window.katex = require("katex");
      
      // Only required if you want to register custom Quill modules
      // const Quill = require("quill");
      // Import and register any additional math-related Quill modules if needed
    }
  }, []);

  // Enhanced configuration for math support
  const modules = {
    toolbar: [
      ["bold", "italic", "underline", "strike"],
      [{ header: 1 }, { header: 2 }],
      [{ list: "ordered" }, { list: "bullet" }],
      [{ script: "sub" }, { script: "super" }], // Subscript and superscript
      ["link", "image", "formula"], // Formula button for KaTeX
      [{ color: [] }, { background: [] }],
      ["clean"]
    ],
    formula: true, // Enable formula module
    clipboard: {
      matchVisual: false // Improves handling of pasted content with formulas
    }
  };

  return (
    <div className="math-editor-container">
      <ReactQuill
        value={value}
        onChange={onChange}
        modules={modules}
        theme="snow"
        placeholder="Type content here... Use the formula button (Σ) to insert mathematical expressions"
      />
      <div className="text-sm text-gray-500 mt-2">
        Tip: Click the formula (Σ) button to insert math equations using LaTeX syntax.
      </div>
    </div>
  );
};

export default MathQuillEditor;