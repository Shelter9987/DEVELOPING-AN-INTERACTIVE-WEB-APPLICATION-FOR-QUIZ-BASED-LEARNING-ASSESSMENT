// "use client";
// import { useEffect, useState } from "react";
// import { useParams } from "next/navigation";
// import dynamic from "next/dynamic";
// import axios from "axios";
// import { useAxios } from "@/utils/ApiHook";

// const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });

// export default function TakeQuizPage() {
//   const { data, isLoading, error, ApiRequest } = useAxios();

//   const { quizId } = useParams();
//   const [quiz, setQuiz] = useState(null);
//   const [answers, setAnswers] = useState([]);

//   useEffect(() => {
//     axios
//       .get(`${process.env.NEXT_PUBLIC_API_URL}/api/acc/quizzes`)
//       .then((res) => {
//         const found = res.data.find((q) => q._id === quizId);
//         setQuiz(found);
//         setAnswers(
//           found?.questions.map(() => ({ roughWork: "", finalAnswer: "" })) ||
//             [],
//         );
//       });
//   }, [quizId]);

//   const handleChange = (i, field, value) => {
//     const updated = [...answers];
//     updated[i][field] = value;
//     setAnswers(updated);
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     ApiRequest(
//       "/acc/sub",
//       "POST",
//       {
//         quizId,
//         answers,
//       },
//       null,
//     );
//     // await axios.post('http://localhost:5000/api/submissions', {
//     //   quizId,
//     //   studentId: 'student_001',
//     //   answers
//     // });
//     alert("Submission sent!");
//   };

//   if (!quiz) return <p className="p-6">Loading...</p>;

//   return (
//     <div className="mx-auto max-w-3xl p-6">
//       <h1 className="mb-4 text-xl font-bold">{quiz.title}</h1>
//       <form onSubmit={handleSubmit} className="space-y-6">
//         {quiz.questions.map((q, i) => (
//           <div key={i} className="rounded border p-4 bg-foreground">
//             <p className="mb-1 font-medium">Question {i + 1}</p>
//             <p className="mb-2">{q.questionText}</p>
//             <label>Rough Work</label>
//             <ReactQuill
//               value={answers[i]?.roughWork}
//               onChange={(v) => handleChange(i, "roughWork", v)}
//             />
//             <label className="mt-2 block">Final Answer</label>
//             <input
//               type="text"
//               className="w-full rounded border p-2"
//               value={answers[i]?.finalAnswer}
//               onChange={(e) => handleChange(i, "finalAnswer", e.target.value)}
//               required
//             />
//           </div>
//         ))}
//         <button
//           type="submit"
//           className="rounded bg-green-600 px-4 py-2 text-white"
//         >
//           Submit
//         </button>
//       </form>
//     </div>
//   );
// }


"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import axios from "axios";
import { useAxios } from "@/utils/ApiHook";
import QuillMathEditor from "@/components/QuillMathEditor";

export default function TakeQuizPage() {
  const { data, isLoading, error, ApiRequest } = useAxios();
  const { quizId } = useParams();
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState([]);

  useEffect(() => {
    axios
      .get(`${process.env.NEXT_PUBLIC_API_URL}/api/acc/quizzes`)
      .then((res) => {
        const found = res.data.find((q) => q._id === quizId);
        setQuiz(found);
        setAnswers(
          found?.questions.map(() => ({ roughWork: "", finalAnswer: "" })) || []
        );
      });
  }, [quizId]);

  const handleChange = (i, field, value) => {
    const updated = [...answers];
    updated[i][field] = value;
    setAnswers(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    ApiRequest("/acc/sub", "POST", {
      quizId,
      answers
    }, null);

    alert("Submission sent!");
  };

  if (!quiz) return <p className="p-6">Loading...</p>;

  return (
    <div className="mx-auto max-w-3xl p-6">
      <h1 className="mb-4 text-xl font-bold">{quiz.title}</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        {quiz.questions.map((q, i) => (
          <div key={i} className="rounded border p-4 bg-foreground">
            <p className="mb-1 font-medium">Question {i + 1}</p>
            <p className="mb-2">{q.questionText}</p>
            <label>Rough Work</label>
            <QuillMathEditor
              value={answers[i]?.roughWork}
              onChange={(v) => handleChange(i, "roughWork", v)}
            />
            <label className="mt-2 block">Final Answer</label>
            <input
              type="text"
              className="w-full rounded border p-2"
              value={answers[i]?.finalAnswer}
              onChange={(e) => handleChange(i, "finalAnswer", e.target.value)}
              required
            />
          </div>
        ))}
        <button
          type="submit"
          className="rounded bg-green-600 px-4 py-2 text-white"
        >
          Submit
        </button>
      </form>
    </div>
  );
}
