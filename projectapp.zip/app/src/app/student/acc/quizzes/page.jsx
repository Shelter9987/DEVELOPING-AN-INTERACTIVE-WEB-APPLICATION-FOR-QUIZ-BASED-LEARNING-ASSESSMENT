'use client';
import { useEffect } from 'react';
import Link from 'next/link';
import { useAxios } from "@/utils/ApiHook";

export default function AllQuizzesPage() {
  const { data: quizzes, isLoading, error, ApiRequest } = useAxios();

  useEffect(() => {
    ApiRequest('/acc/quizzes', 'GET', null, null);
  }, []);

  return (
    <div className="mx-auto max-w-3xl p-6">
      <h1 className="mb-4 text-2xl font-bold">Available Quizzes</h1>

      {isLoading && (
        <p className="text-gray-500">Loading quizzes...</p>
      )}

      {error && (
        <p className="text-red-600">Failed to load quizzes. Please try again later.</p>
      )}

      {!isLoading && !error && (!quizzes || quizzes.length === 0) && (
        <p>No quizzes available at the moment. Please check back later.</p>
      )}

      <ul className="space-y-4">
        {quizzes?.map((quiz) => (
          <li key={quiz._id} className="rounded border p-4 shadow-md bg-foreground">
            <h2 className="text-lg font-semibold">{quiz.title}</h2>
            <p className="text-sm text-gray-600">
              {quiz.description || 'No description available'}
            </p>
            <Link
              href={`/student/acc/take/${quiz._id}`}
              className="mt-2 inline-block text-blue-600 hover:underline"
            >
              Start Quiz
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
