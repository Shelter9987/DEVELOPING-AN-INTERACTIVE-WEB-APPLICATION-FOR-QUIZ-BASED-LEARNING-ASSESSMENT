import AccountingCalculator from '@/components/accounting-calculator'
import React from 'react'

const Calculate = () => {
  return (
    <div>
        <AccountingCalculator/>
    </div>
  )
}

export default Calculate