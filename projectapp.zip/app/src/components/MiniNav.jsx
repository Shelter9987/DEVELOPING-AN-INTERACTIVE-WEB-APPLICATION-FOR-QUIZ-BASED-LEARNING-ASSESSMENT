"use client";
import React from "react";
import { usePathname } from "next/navigation";
import { FaHome, FaArrowRight } from "react-icons/fa";
import Link from "next/link";

const MiniNav = () => {
  const pathname = usePathname();

  const pathSegments = pathname.split("/").filter(Boolean);

  return (
    <nav className="mb-8 flex rounded-lg bg-foreground p-4 text-sm">
      <div className="inline-flex items-center space-x-3">
        <div className="flex items-center gap-2 text-sm">
          <FaHome />
          <Link href={"/"}>Home</Link>
        </div>
        {pathSegments.map((segment, index) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <FaArrowRight />
            <Link href={`/${pathSegments.slice(0, index + 1).join("/")}`}>
              {segment.charAt(0).toUpperCase() + segment.slice(1)}
            </Link>
          </div>
        ))}
      </div>
    </nav>
  );
};

export default MiniNav;
