'use client';
import { useEffect } from 'react';
import { useAxios } from "@/utils/ApiHook";

export default function StudentResultsPage() {
  const { data, isLoading, error, ApiRequest } = useAxios();

  useEffect(() => {
    ApiRequest('/acc/sub-student/', 'GET', null, null);
  }, []);

  return (
    <div className="mx-auto max-w-3xl p-6">
      <h1 className="mb-4 text-2xl font-bold">My Quiz Results</h1>

      {isLoading && (
        <div className="flex items-center justify-center">
          <div className="text-lg font-semibold text-gray-700">
            Loading results...
          </div>
        </div>
      )}

      {error && (
        <p className="text-red-600 mb-4">Failed to fetch results. Please try again later.</p>
      )}

      {!isLoading && !error && data?.length === 0 && (
        <p>No submissions found.</p>
      )}

      {data?.map((s, idx) => (
        <div key={idx} className="mb-4 rounded border p-4 shadow-md bg-foreground">
          <h3 className="text-lg font-semibold">Quiz: {s.quizId?.title || 'Untitled'}</h3>
          <p className="text-sm text-gray-600">
            Date Submitted: {new Date(s.createdAt).toLocaleDateString()}
          </p>
          <p className="mt-2">
            <strong>Score:</strong> {s.score ?? 'Not Available'}
          </p>
          <p className="mt-2">
            <strong>Remarks:</strong> {s.remarks || 'No remarks yet.'}
          </p>
        </div>
      ))}
    </div>
  );
}
