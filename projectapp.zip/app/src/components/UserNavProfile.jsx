"use client";
import { Context } from "@/utils/Context";
import {
  Avatar,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownTrigger,
  NavbarContent,
} from "@nextui-org/react";
import { useRouter } from "next/navigation";
import { useContext, useState } from "react";

const UserNavProfile = () => {
  const router = useRouter();
  const { user, logout } = useContext(Context);
  const [toggle, setToggle] = useState(false);

  const handleNavigate = (path) => {
    if (user.role === "user") {
      router.push("/user" + path);
    }
    if (user.role === "admin") {
      router.push("/admin" + path);
    }
    setToggle(!toggle);
  };

  const handlelogout = () => {
    // e.preventDefault();
    logout();
    setToggle(!toggle);
    router.push("/");
  };

  return (
    <NavbarContent as="div" justify="end">
      <Dropdown placement="bottom-end">
        <DropdownTrigger>
          <div className="flex justify-center gap-3">
            <Avatar
              isBordered
              as="button"
              className="transition-transform"
              color="primary"
              name={user?.name}
              size="sm"
              src={user?.profile}
            />
          </div>
        </DropdownTrigger>
        <DropdownMenu aria-label="Profile Actions" variant="flat">
          <DropdownItem key="profile" className="h-14 gap-2">
            <p className="font-semibold">Signed in as</p>
            <p className="font-semibold"> {user?.email}</p>
          </DropdownItem>
          <DropdownItem key="settings">profile Settings</DropdownItem>

          <DropdownItem onClick={handlelogout} key="logout" color="danger">
            Log Out
          </DropdownItem>
        </DropdownMenu>
      </Dropdown>
    </NavbarContent>
  );
};

export default UserNavProfile;
