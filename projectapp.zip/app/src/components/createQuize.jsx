"use client";
import { useAxios } from "@/utils/ApiHook";
import {
  Autocomplete,
  AutocompleteItem,
  Button,
  Input,
  Textarea,
} from "@nextui-org/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function QuizForm({ quize }) {
  const router = useRouter();
  const initial = {
    title: "",
    desc: "",
    marks_allocated: 20,
    questions: [],
    courseId: "",
    start_time: new Date().toISOString().slice(0, 16), // Format for datetime-local input
    end_time: new Date().toISOString().slice(0, 16),
  };
  const [formData, setFormData] = useState(quize || initial);
  const [isEditMode, setIsEditMode] = useState(Boolean(quize));

  const { data, isLoading, ApiRequest } = useAxios();

  const {
    data: coursesData,
    isLoading: coursesLoading,
    ApiRequest: getCourse,
  } = useAxios();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isEditMode) {
      // Update an existing quiz
      await ApiRequest(`/quize/${formData._id}/update`, "PUT", formData, null);
    } else {
      // Create a new quiz
      await ApiRequest("/quize/create", "POST", formData, null);
    }
  };

  useEffect(() => {
    getCourse("/courses/?sortBy=createdAt&pageSize=all", "GET", null, null);
  }, []);

  useEffect(() => {
    if (data) {
      // setFormData(initial);
      if (!isEditMode) {
        router.push(`/lecturer/quizes/${data.data._id}`);
      }
      router.refresh();
    }
  }, [data]);

  return (
    <form
      onSubmit={handleSubmit}
      className="mb-8 flex flex-col items-center justify-center gap-4 rounded-xl bg-foreground p-4"
    >
      <h2 className="text-center text-2xl font-bold">
        {isEditMode ? "Edit Quiz" : "Organize Quiz"}
      </h2>
      <Autocomplete
        name="courseId"
        color="primary"
        isRequired
        label="Select Course"
        selectedKey={formData?.courseId}
        onSelectionChange={(newCourseId) =>
          setFormData((prev) => ({ ...prev, courseId: newCourseId }))
        }
      >
        {coursesData?.data?.map((item) => (
          <AutocompleteItem key={item._id}>
            {item.course_name + " " + item.course_code}
          </AutocompleteItem>
        ))}
      </Autocomplete>
      <div className="flex w-full justify-between gap-4">
        <Input
          labelPlacement="outside-left"
          color="primary"
          label="Start Time:"
          type="datetime-local"
          name="start_time"
          value={formData.start_time}
          onChange={handleChange}
          isRequired
        />
        <Input
          labelPlacement="outside-left"
          color="primary"
          label="End Time:"
          type="datetime-local"
          name="end_time"
          value={formData.end_time}
          onChange={handleChange}
          isRequired
        />
      </div>
      <Textarea
        color="primary"
        label="Quiz Title:"
        isRequired
        name="title"
        value={formData.title}
        onChange={handleChange}
      />
      <Textarea
        color="primary"
        label="Description or Instructions:"
        name="desc"
        value={formData.desc}
        onChange={handleChange}
      />
      <Input
        color="primary"
        label="Marks Allocated:"
        isRequired
        name="marks_allocated"
        type="number"
        value={formData.marks_allocated}
        onChange={handleChange}
      />
      <Button
        isLoading={isLoading}
        className="w-full"
        color="primary"
        type="submit"
      >
        {isEditMode ? "Save Changes" : "Proceed to Add Questions"}
      </Button>
    </form>
  );
}

// "use client";
// import { useAxios } from "@/utils/ApiHook";
// import {
//   Autocomplete,
//   AutocompleteItem,
//   Button,
//   Input,
//   Textarea
// } from "@nextui-org/react";
// import { useRouter } from "next/navigation";
// import { useEffect, useState } from "react";

// export default function CreateQuize({ quiz }) {
//   const router = useRouter();
//   const initial = {
//     title: "",
//     desc: "",
//     marks_allocated: 20,
//     questions: [],
//     courseId: "",
//     start_time: new Date(),
//     end_time: new Date(),
//   };
//   const [formData, setFormData] = useState(initial);

//   const { data, isLoading, ApiRequest } = useAxios();

//   const {
//     data: coursesData,
//     isLoading: coursesLoading,
//     ApiRequest: getCourse,
//   } = useAxios();

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     if (name.startsWith("options.")) {
//       setFormData((prev) => ({ ...prev, [name.split(".")[1]]: value }));
//     } else {
//       setFormData({ ...formData, [name]: value });
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     ApiRequest("/quize/create", "POST", formData, null);
//   };

//   useEffect(() => {
//     getCourse("/courses/?sortBy=createdAt&pageSize=all", "GET", null, null);
//   }, []);

//   useEffect(() => {
//     if (data) {
//       setFormData(initial);
//       router.push(`/lecturer/quizes/${data.data._id}`);
//     }
//   }, [data]);

//   return (
//     <form
//       onSubmit={handleSubmit}
//       className="mb-8 flex flex-col items-center justify-center gap-4 rounded-xl bg-foreground p-4"
//     >
//       <h2 className="text-center text-2xl font-bold">Organize Quize</h2>
//       <Autocomplete
//         name="courseId"
//         color="primary"
//         isRequired
//         label="Select Course"
//         // onChange={handleChange}
//         selectedKey={formData?.courseId}
//         onSelectionChange={(newCourseId) =>
//           setFormData((prev) => ({ ...prev, courseId: newCourseId }))
//         }
//       >
//         {coursesData?.data?.map((item, i) => (
//           <AutocompleteItem key={item._id}>
//             {item.course_name + " " + item.course_code}
//           </AutocompleteItem>
//         ))}
//       </Autocomplete>{" "}
//       <div className="flex w-full justify-between gap-4">
//         <Input
//           labelPlacement="outside-left"
//           color="primary"
//           label="Start Time:"
//           type="datetime-local"
//           name="start_time"
//           value={formData.start_time}
//           onChange={handleChange}
//           isRequired
//         />
//         <Input
//           labelPlacement="outside-left"
//           color="primary"
//           label="End Time:"
//           type="datetime-local"
//           name="end_time"
//           value={formData.end_time}
//           onChange={handleChange}
//           isRequired
//         />
//       </div>
//       <Textarea
//         color="primary"
//         label="Quize Title:"
//         isRequired
//         name="title"
//         value={formData.title}
//         onChange={handleChange}
//       />
//       <Textarea
//         color="primary"
//         label="desc or Instructions"
//         name="desc"
//         value={formData.desc}
//         onChange={handleChange}
//       />
//       <Input
//         color="primary"
//         label="Marks Allocated:"
//         isRequired
//         name="marks_allocated"
//         value={formData.marks_allocated}
//         onChange={handleChange}
//       />
//       <Button
//         isLoading={isLoading}
//         className="w-full"
//         color="primary"
//         type="submit"
//       >
//         proceed to add questions
//       </Button>
//     </form>
//   );
// }
