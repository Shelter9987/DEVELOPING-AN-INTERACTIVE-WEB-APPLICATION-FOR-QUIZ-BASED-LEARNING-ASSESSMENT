"use client";
import { useEffect, useState } from "react";
import { useAxios } from "./ApiHook";
import { exportToExcel } from "./utils";

export function DownloadHook() {
  const { data, error, ApiRequest, isLoading: downLoading } = useAxios();
  const [filename, setFilename] = useState("");

  useEffect(() => {
    if (data) {
      exportToExcel(data?.data, filename);
    }
  }, [data]);

  const downloadData = async (path, params) => {
    setFilename(params.slug[0] + "_" + path);

    ApiRequest(
      `/${path}/?companyId=${params.slug[1]}&&pageSize=all`,
      "GET",
      null,
      null,
    );
  };
  return { downloadData, downLoading };
}
