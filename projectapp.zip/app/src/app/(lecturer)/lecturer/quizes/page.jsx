"use client";
import CreateQuize from "@/components/createQuize";
import Modalcomponent from "@/components/Modalcomponent";
import { useAxios } from "@/utils/ApiHook";
import {
  Button,
  Input,
  Pagination,
  Spinner,
  Table,
  TableBody,
  TableCell,
  TableColumn,
  TableHeader,
  TableRow,
} from "@nextui-org/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { BsSearch } from "react-icons/bs";

const columns = [
  {
    key: "title",
    label: "Title",
  },
  {
    key: "start_time",
    label: "Start Time",
  },
  {
    key: "end_time",
    label: "End Time",
  },
  {
    key: "marks_allocated",
    label: "Marks",
  },
  {
    key: "actions",
    label: "Actions",
  },
];

const Quize = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [ComponentToRender, setComponentToRender] = useState(null);
  const [title, setTitle] = useState("");

  const handleOpenModal = (Component, title) => {
    setTitle(title);
    setComponentToRender(() => Component);
    setIsOpen(true);
  };

  const router = useRouter();
  const { data, isLoading, ApiRequest } = useAxios();
  console.log({ data });

  const [params, setParams] = useState({
    search: "",
    page: 1,
    pageSize: 10,
  });

  useEffect(() => {
    ApiRequest("/quize/my/", "GET", null, params);
  }, [params]);

  const renderCell = React.useCallback((item, columnKey) => {
    const cellValue = item[columnKey];
    switch (columnKey) {
      case "start_time":
        return item.start_time
          ? new Date(item.start_time).toLocaleString()
          : "Not set yet";
      case "end_time":
        return item.end_time
          ? new Date(item.end_time).toLocaleString()
          : "Not set yet";
      case "actions":
        return (
          <Button as={Link} href={`/lecturer/quizes/${item._id}`}>
            View
          </Button>
        );
      default:
        return cellValue;
    }
  }, []);

  const topContent = React.useMemo(() => {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex items-end justify-between gap-3">
          <Input
            className="w-full sm:max-w-[44%]"
            placeholder="Search ..."
            startContent={<BsSearch />}
            onChange={(e) => setParams({ ...params, search: e.target.value })}
          />
          <label htmlFor="page" className="flex items-center">
            Rows per page:
            <select
              id="page"
              value={params.pageSize}
              className="bg-transparent outline-none"
              onChange={(e) =>
                setParams({ ...params, pageSize: e.target.value })
              }
            >
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="15">15</option>
              <option value="all">All</option>
            </select>
          </label>
        </div>
      </div>
    );
  }, [params]);

  return (
    <>
      <div className="flex flex-col gap-4">
        <Button
          color="primary"
          onClick={() => handleOpenModal(<CreateQuize />, "New Quize")}
        >
          New Quize
        </Button>
        <Table topContent={topContent} isStriped aria-label="table">
          <TableHeader columns={columns}>
            {(column) => (
              <TableColumn key={column.key}>{column.label}</TableColumn>
            )}
          </TableHeader>

          <TableBody
            loadingContent={
              <Spinner size="lg" className="m-8" label="Loading..." />
            }
            isLoading={isLoading}
            items={data ? data.data : []}
          >
            {(item) => (
              <TableRow key={item._id}>
                {(columnKey) => (
                  <TableCell>{renderCell(item, columnKey)}</TableCell>
                )}
              </TableRow>
            )}
          </TableBody>
        </Table>
        <div className="mb-8 flex w-full justify-center py-8 lg:mb-20">
          <Pagination
            isCompact
            showControls
            showShadow
            color="secondary"
            page={params.page}
            total={data ? data.pages : 1}
            onChange={(page) => setParams({ ...params, page })}
          />
        </div>
      </div>
      <Modalcomponent
        title={title}
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        Component={ComponentToRender}
        size="3xl"
      />
    </>
  );
};

export default Quize;
