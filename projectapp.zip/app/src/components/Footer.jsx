"use client";
import Link from "next/link";

const Footer = () => {
  return (
    <>
      {/* Footer Section */}
      <footer className="bg-gray-800 py-8 text-white">
        <div className="container mx-auto px-4 text-center">
          <p className="mb-4">© 2025 QuizeApp. All rights reserved.</p>
          <div className="flex justify-center space-x-4">
            <a href="#" className="hover:underline">
              About
            </a>
            <a href="#" className="hover:underline">
              Contact
            </a>
            <a href="#" className="hover:underline">
              Privacy Policy
            </a>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
