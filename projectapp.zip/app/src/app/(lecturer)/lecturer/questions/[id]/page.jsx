import React from 'react'

const Question = () => {
  return (
    <div>Question</div>
  )
}

export default Question