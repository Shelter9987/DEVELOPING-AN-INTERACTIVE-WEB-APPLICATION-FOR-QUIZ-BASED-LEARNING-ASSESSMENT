"use client";
import React, { useEffect, useState } from "react";
import QuizCard from "@/components/QuizCard";
import { useAxios } from "@/utils/ApiHook";
import { useRouter } from "next/navigation";

const QUESTIONS_PER_PAGE = 10;

const QuizWizard = ({ params }) => {
  const router = useRouter();
  const { data, isLoading, error, ApiRequest } = useAxios();
  const { ApiRequest: submitQuize } = useAxios();
  const [answers, setAnswers] = useState({});
  const [page, setPage] = useState(1);
  const QUIZ_PROGRESS_KEY = `quiz_progress_${params.id}`;

  // Load quiz data and progress
  useEffect(() => {
    ApiRequest(`/quize/${params.id}/`, "GET", null, null);

    const saved = localStorage.getItem(QUIZ_PROGRESS_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setAnswers(parsed);
      } catch (e) {
        console.warn("Invalid saved progress");
      }
    }
  }, [params]);

  // Save to localStorage on change
  useEffect(() => {
    if (Object.keys(answers).length > 0) {
      localStorage.setItem(QUIZ_PROGRESS_KEY, JSON.stringify(answers));
    }
  }, [answers]);

  const handleChange = (e, questionIndex) => {
    const { value } = e.target;
    setAnswers((prev) => ({
      ...prev,
      [`question_${questionIndex}`]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formattedAnswers = data.data.questions.map((_, index) => ({
      selectedAnswer: answers[`question_${index}`] || null,
    }));

    const payload = {
      quizId: params.id,
      answers: formattedAnswers,
    };

    try {
      await submitQuize("/quize/take/", "POST", payload, null);
      localStorage.removeItem(QUIZ_PROGRESS_KEY);
      // alert("Quiz submitted successfully!");

      router.push("/results/"); // Redirect to quiz list or results page
    } catch (err) {
      console.error(err);
      alert("Submission failed.");
    }
  };

  // Pagination logic
  const totalQuestions = data?.data?.questions?.length || 0;
  const totalPages = Math.ceil(totalQuestions / QUESTIONS_PER_PAGE);
  const startIndex = (page - 1) * QUESTIONS_PER_PAGE;
  const currentQuestions = data?.data?.questions?.slice(
    startIndex,
    startIndex + QUESTIONS_PER_PAGE,
  );

  return (
    <div className="container mx-auto max-w-4xl p-6">
      {isLoading && <p className="text-center text-gray-500">Loading...</p>}

      {error && (
        <div className="rounded bg-red-500 p-4 text-white">
          Failed to load quiz data.
        </div>
      )}

      {data && (
        <>
          <QuizCard quiz={data.data} />
          <form onSubmit={handleSubmit} className="space-y-6">
            {currentQuestions?.map((question, index) => {
              const actualIndex = startIndex + index;

              return (
                <div
                  key={actualIndex}
                  className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
                >
                  <h3 className="mb-3 text-lg font-semibold">
                    {actualIndex + 1}. {question.questionText}
                  </h3>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {Object.entries(question.options || {}).map(
                      ([key, value]) => (
                        <label
                          key={key}
                          className={`flex cursor-pointer items-center gap-2 rounded border p-2 transition ${
                            answers[`question_${actualIndex}`] === key
                              ? "border-blue-500 bg-blue-100"
                              : "hover:bg-gray-50"
                          }`}
                        >
                          <input
                            type="radio"
                            name={`question_${actualIndex}`}
                            value={key}
                            checked={answers[`question_${actualIndex}`] === key}
                            onChange={(e) => handleChange(e, actualIndex)}
                            className="accent-blue-600"
                          />
                          <span>
                            <strong>{key}</strong>: {value}
                          </span>
                        </label>
                      ),
                    )}
                  </div>
                </div>
              );
            })}

            <div className="mt-4 flex items-center justify-between">
              <div className="space-x-2">
                <button
                  type="button"
                  onClick={() => setPage((p) => Math.max(p - 1, 1))}
                  disabled={page === 1}
                  className="rounded bg-gray-200 px-4 py-2 hover:bg-gray-300 disabled:opacity-50"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setPage((p) => Math.min(p + 1, totalPages))}
                  disabled={page === totalPages}
                  className="rounded bg-gray-200 px-4 py-2 hover:bg-gray-300 disabled:opacity-50"
                >
                  Next
                </button>
              </div>

              {page === totalPages && (
                <button
                  type="submit"
                  className="rounded bg-blue-600 px-6 py-2 text-white hover:bg-blue-700"
                >
                  Submit Quiz
                </button>
              )}
            </div>
          </form>
        </>
      )}
    </div>
  );
};

export default QuizWizard;
