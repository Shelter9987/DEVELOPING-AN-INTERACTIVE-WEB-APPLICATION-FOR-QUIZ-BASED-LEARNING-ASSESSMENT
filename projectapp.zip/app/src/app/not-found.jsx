"use client";
import { Button } from "@nextui-org/react";
import Link from "next/link";
import { useRouter } from "next/navigation";

const NotFound = () => {
  const router = useRouter();
  return (
    <div className="lg:py-12 h-screen">
      <div className="container p-4 mx-auto rounded-b-2xl py-20">
        <h1 className="mb-8 text-center text-3xl font-bold md:text-3xl">
          404 - Page not found
        </h1>

        <p className="mb-12 container text-center text-copy md:text-lg">
          The page you’re looking for doesn’t exist.
        </p>
        <div className="flex gap-4 item-center justify-center">
          <Button size="lg" as={Link} color="primary" variant="shadow" href="/">
            Go to Home
          </Button>
          <Button
            size="lg"
            color="secondary"
            variant="ghost"
            href="/"
            onPress={() => router.back()}
          >
            Go Back
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
