"use client";
import { useAxios } from "@/utils/ApiHook";
import React, { useEffect, useState } from "react";
import QuestionsCard from "./QuestionsCard";
import { Pagination } from "@nextui-org/react";

const QuestionList = ({ quize }) => {
  const { data, isLoading, ApiRequest } = useAxios();

  const [params, setParams] = useState({
    search: "",
    page: 1,
    pageSize: 10,
  });

  useEffect(() => {
    ApiRequest(
      `/questions/?sortBy=createdAt&courseId=${quize.courseId}`,
      "GET",
      null,
      params,
    );
  }, [params]);
  return (
    <div>
      {data && (
        <div className="space-y-4">
          {data?.data.map((question, index) => (
            <QuestionsCard question={question} key={index} />
          ))}
        </div>
      )}
      <div className="mb-8 flex w-full justify-center py-8 lg:mb-20">
        <Pagination
          isCompact
          showControls
          showShadow
          color="secondary"
          page={params.page}
          total={data ? data.pages : 1}
          onChange={(page) => setParams({ ...params, page })}
        />
      </div>
    </div>
  );
};

export default QuestionList;
