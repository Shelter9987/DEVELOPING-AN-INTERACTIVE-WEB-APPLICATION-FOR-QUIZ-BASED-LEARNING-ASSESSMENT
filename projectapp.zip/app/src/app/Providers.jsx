// app/providers.tsx
"use client";
import { ContextProvider } from "@/utils/Context";
import { NextUIProvider } from "@nextui-org/react";
import { ThemeProvider as NextThemesProvider } from "next-themes";
import { GoogleOAuthProvider } from "@react-oauth/google";

export function Providers({ children }) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="light"
      themes={["light", "dark"]}
      value="light"
    >
      {" "}
      <GoogleOAuthProvider clientId={process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID}>
        <ContextProvider>
          <NextUIProvider>{children}</NextUIProvider>
        </ContextProvider>{" "}
      </GoogleOAuthProvider>
    </NextThemesProvider>
  );
}
