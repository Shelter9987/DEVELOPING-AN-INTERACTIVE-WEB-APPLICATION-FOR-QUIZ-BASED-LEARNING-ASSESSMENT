import { Inter } from "next/font/google";
import { Toaster } from "react-hot-toast";
import "./globals.css";
import { Providers } from "./Providers";
import Navbartop from "@/components/Navbar";
import Footer from "@/components/Footer";
import 'react-quill/dist/quill.snow.css';

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Home",
  description: "Excellent quize app",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="bg-background">
      <body className={inter.className}>
        {" "}
        <main className="">
          <Providers>
            <Toaster />

            <Navbartop />
            <div className="min-h-screen">{children}</div>
            <Footer />
          </Providers>
        </main>
      </body>
    </html>
  );
}
