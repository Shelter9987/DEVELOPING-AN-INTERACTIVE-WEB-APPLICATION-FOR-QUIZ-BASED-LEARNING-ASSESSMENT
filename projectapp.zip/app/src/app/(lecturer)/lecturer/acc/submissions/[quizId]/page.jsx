"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useAxios } from "@/utils/ApiHook";

export default function SubmissionsPage() {
  const { quizId } = useParams();
  const { data, isLoading, error, ApiRequest } = useAxios();

  useEffect(() => {
    ApiRequest(`/acc/sub/quiz/${quizId}`, "GET", null, null);
  }, [quizId]);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-lg font-semibold text-gray-700">
          Loading submissions...
        </div>
      </div>
    );
  }
   
  if (error) {
    return (
      <div className="mx-auto max-w-3xl p-6 text-center">
        <h1 className="text-2xl font-bold text-red-600">Error</h1>
        <p className="text-gray-700">{error.message}</p>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="mx-auto max-w-3xl p-6 text-center">
        <h1 className="mb-2 text-2xl font-bold text-gray-800">
          No Submissions Yet
        </h1>
        <p className="text-gray-600">
          Students haven’t submitted their work for this quiz.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl p-6">
      <h1 className="mb-6 text-3xl font-bold text-gray-900">
        Student Submissions
      </h1>
      <div className="grid gap-6 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {data.map((submission) => (
          <div
            key={submission._id}
            className="rounded-2xl border border-gray-200 bg-foreground p-5 shadow-sm transition-shadow duration-200 hover:shadow-md"
          >
            <div className="mb-2">
              <h2 className="text-xl font-semibold text-gray-800">
                {/* {submission.studentId.name} */}
              </h2>
              <p className="text-sm text-gray-500">
                Submitted:{" "}
                {new Date(submission.createdAt).toLocaleDateString()}
              </p>
            </div>

            <div className="mt-4 space-y-1">
              <p className="text-gray-700">
                <span className="font-medium">Score:</span>{" "}
                {submission.score ?? (
                  <span className="italic text-gray-500">Not Marked Yet</span>
                )}
              </p>
              <Link
                href={`/lecturer/acc/mark/${submission._id}`}
                className="mt-3 inline-block rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700"
              >
                Mark Submission
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
