"use client";
import { Context } from "@/utils/Context";
import { useRouter, useSearchParams } from "next/navigation";
import { useContext, useEffect } from "react";
import { Suspense } from "react";

const Layout = ({ children }) => {
  const searchParams = useSearchParams();
  const callback = searchParams.get("callback");

  const { user } = useContext(Context);
  const router = useRouter();

  useEffect(() => {
    if (user) {
      if (callback) {
        router.push(callback);
      } else if (user.role === "admin") {
        router.push("/");
      } else {
        router.push("/");
      }
    }
  }, [user]);

  return (
    <Suspense>
      <div className="bg-background py-8 lg:py-12 xl:min-h-screen">
        {children}
      </div>{" "}
    </Suspense>
  );
};

export default Layout;
