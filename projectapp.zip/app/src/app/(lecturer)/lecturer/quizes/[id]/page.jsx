import React from "react";
import { fetchWithAuth } from "@/utils/fetchWithAuth";
import QuizCard from "@/components/QuizCard";
import QuestionsCard from "@/components/QuestionsCard";

const QuizeWizard = async ({ params }) => {
  const { data } = await fetchWithAuth(`/api/quize/${params.id}`);

  // console.log("Quiz Data:", data);

  return (
    <div className="container mx-auto">
      {!data && (
        <div className="w-full rounded-xl bg-red-500 p-4 text-white shadow-lg">
          Failed to load quiz data.
        </div>
      )}
      {data && <QuizCard quiz={data} />}
      {data && (
        <div className="w-full rounded-xl bg-foreground p-4 py-4 shadow-lg">
          {/* {data?._id || "No quiz found"} */}
          {data.questions.map((question, index) => (
            <QuestionsCard question={question} key={index} />
          ))}
        </div>
      )}
    </div>
  );
};

export default QuizeWizard;
