import ExcelJS from "exceljs";
import { saveAs } from "file-saver";

export const exportToExcel = async (rawData, filename = "data.xlsx") => {
  // Clean up the data by removing unwanted fields from each object
  const data = rawData.map((item) => {
    const newItem = { ...item };
    delete newItem._id;
    delete newItem.__v;
    delete newItem.userId;
    delete newItem.companyId;
    delete newItem.updatedAt;
    delete newItem.createdAt;
    return newItem;
  });

  // Create a new workbook and worksheet
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("Sheet1");

  // Function to calculate column letters beyond Z (AA, AB, etc.)
  const getExcelColumnLetter = (colNum) => {
    let letter = "";
    while (colNum > 0) {
      let modulo = (colNum - 1) % 26;
      letter = String.fromCharCode(65 + modulo) + letter;
      colNum = Math.floor((colNum - 1) / 26);
    }
    return letter;
  };

  // Add a title row with the filename and style it
  const titleRow = worksheet.addRow([filename]);
  titleRow.font = { bold: true, size: 16 };

  const lastColumnLetter = getExcelColumnLetter(Object.keys(data[0]).length);
  worksheet.mergeCells(`A1:${lastColumnLetter}1`);
  titleRow.getCell(1).alignment = { horizontal: "center", vertical: "middle" };

  // Add some spacing between the title and the table
  worksheet.addRow([]);

  // Extract headers from the cleaned data
  const headers = Object.keys(data[0]);
  const headerRow = worksheet.addRow(headers);

  // Style the header row
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF4CAF50" }, // Green background
    };
    cell.alignment = { horizontal: "center", vertical: "middle" };
    cell.border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
  });

  // Add data rows dynamically, making sure the values align with headers
  data.forEach((item) => {
    const rowValues = headers.map((header) => item[header] || ""); // Match values with headers
    worksheet.addRow(rowValues);
  });

  // Adjust column widths
  worksheet.columns.forEach((column) => {
    column.width = 20; // Set a fixed width for each column
  });

  // Generate the Excel file and download it
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  saveAs(blob, filename);
};



// export const exportToExcel = async (rawData, filename = "data.xlsx") => {
//   const data = rawData.map((item) => {
//     const newItem = { ...item };
//     delete newItem._id;
//     delete newItem.__v;
//     delete newItem.userId;
//     delete newItem.companyId;
//     delete newItem.updatedAt;
//     delete newItem.createdAt;
//     return newItem;
//   });

//   // Create a new workbook and worksheet
//   const workbook = new ExcelJS.Workbook();
//   const worksheet = workbook.addWorksheet("Sheet1");

//   // Add a title row with the filename and style it
//   const titleRow = worksheet.addRow([filename]);
//   titleRow.font = { bold: true, size: 16 };
//   worksheet.mergeCells(
//     `A1:${String.fromCharCode(65 + Object.keys(data[0]).length - 1)}1`,
//   );
//   titleRow.getCell(1).alignment = { horizontal: "center", vertical: "middle" };

//   // Add some spacing between the title and the table
//   worksheet.addRow([]);

//   // Add header row with column names
//   const headerRow = worksheet.addRow(Object.keys(data[0]));

//   // Style the header row
//   headerRow.eachCell((cell) => {
//     cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
//     cell.fill = {
//       type: "pattern",
//       pattern: "solid",
//       fgColor: { argb: "FF4CAF50" }, // Green background
//     };
//     cell.alignment = { horizontal: "center", vertical: "middle" };
//     cell.border = {
//       top: { style: "thin" },
//       left: { style: "thin" },
//       bottom: { style: "thin" },
//       right: { style: "thin" },
//     };
//   });

//   // Add data rows
//   data.forEach((item) => {
//     worksheet.addRow(Object.values(item));
//   });

//   // Adjust column widths
//   worksheet.columns.forEach((column) => {
//     column.width = 20; // Set a fixed width for each column
//   });

//   const buffer = await workbook.xlsx.writeBuffer();

//   const blob = new Blob([buffer], {
//     type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
//   });
//   saveAs(blob, filename);
// };


