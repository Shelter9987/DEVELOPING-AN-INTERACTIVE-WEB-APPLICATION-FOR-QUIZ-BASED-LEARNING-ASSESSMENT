import { Button } from "@nextui-org/react";
import Link from "next/link";

const Hero = () => {
  return (
    <>
      <div className="container mx-auto flex min-h-[60vh] flex-col p-4 pt-20 lg:flex-row">
        <div className="flex-1 space-y-8">
          <h1 className="text-4xl font-bold lg:text-6xl">
            welcome to our quizze platform
          </h1>
          <p className=""></p>
          <div className="flex w-full gap-8">
            <Button
              as={Link}
              href="/login"
              radius="none"
              size="lg"
              color="primary"
            >
              Get Started
            </Button>
          </div>
        </div>
        {/* <div className="flex w-full flex-1 items-center justify-center"></div> */}
      </div>
    </>
  );
};

export default Hero;
