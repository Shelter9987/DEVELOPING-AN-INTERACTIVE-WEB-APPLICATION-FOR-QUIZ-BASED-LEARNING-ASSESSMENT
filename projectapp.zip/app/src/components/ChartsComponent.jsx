
import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  Title,
  Tooltip,
} from "chart.js";
import { Bar } from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
);
const ChartsComponent = ({ data, fields, title }) => {
  const years = data.map((entry) => entry.year);
  const colors = [
    { background: "rgba(75, 192, 192, 0.6)", border: "rgba(75, 192, 192, 1)" },
    { background: "rgba(192, 75, 192, 0.6)", border: "rgba(192, 75, 192, 1)" },
    { background: "rgba(192, 192, 75, 0.6)", border: "rgba(192, 192, 75, 1)" },
    { background: "rgba(75, 75, 192, 0.6)", border: "rgba(75, 75, 192, 1)" },
    { background: "rgba(192, 75, 75, 0.6)", border: "rgba(192, 75, 75, 1)" },
    { background: "rgba(75, 192, 75, 0.6)", border: "rgba(75, 192, 75, 1)" },
  ];
  const barData = {
    labels: years,

    datasets: fields.map((field, index) => ({
      label: `${field} (in GHS)`,
      data: data.map((entry) => entry[field]),

      backgroundColor:
        colors[index % colors.length].background ??
        `rgba(${75 + index * 20}, ${192 + index - 10}, ${192 + index - 20}, 0.6)`,
      borderColor:
        colors[index % colors.length].border ??
        `rgba(${75 + index * 20}, 192, 192, 1)`,
      borderWidth: 1,
    })),
  };
  const options = {
    responsive: true,
    datasetIndex: 1,
  };
  return (
    <div className="container mx-auto my-8 space-y-4 p-4 bg-foreground">
      <h3 className="text-center text-xl font-bold uppercase p-4">
        Chart Analytic for {title}
      </h3>
      <Bar options={options} data={barData} />
    </div>
  );
};

export default ChartsComponent;
