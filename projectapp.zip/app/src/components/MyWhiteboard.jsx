// "use client";
// import { useRef } from 'react';
// import { ReactSketchCanvas } from 'react-sketch-canvas';

// export default function MyWhiteboard() {
//   const canvasRef = useRef(null);
  
//   const styles = {
//     border: '1px solid #ccc',
//     borderRadius: '4px',
//   };
  
//   const clearCanvas = () => {
//     canvasRef.current.clearCanvas();
//   };
  
//   const undoAction = () => {
//     canvasRef.current.undo();
//   };
  
//   const redoAction = () => {
//     canvasRef.current.redo();
//   };
  
//   const changeColor = (color) => {
//     canvasRef.current.eraseMode(false);
//     canvasRef.current.setStrokeColor(color);
//   };
  
//   const toggleEraser = () => {
//     canvasRef.current.eraseMode(true);
//   };
  
//   return (
//     <div className="flex flex-col h-full w-full">
//       <div className="flex justify-between items-center p-4 bg-gray-100 border-b">
//         <div className="flex items-center space-x-4">
//           <button
//             onClick={() => changeColor('#000000')}
//             className="w-8 h-8 bg-black border border-gray-300 rounded-full"
//           />
//           <button
//             onClick={() => changeColor('#FF0000')}
//             className="w-8 h-8 bg-red-600 border border-gray-300 rounded-full"
//           />
//           <button
//             onClick={() => changeColor('#0000FF')}
//             className="w-8 h-8 bg-blue-600 border border-gray-300 rounded-full"
//           />
//           <button
//             onClick={toggleEraser}
//             className="px-3 py-1 bg-white border border-gray-300 rounded"
//           >
//             Eraser
//           </button>
//         </div>
//         <div className="flex space-x-2">
//           <button
//             onClick={undoAction}
//             className="px-4 py-2 bg-blue-500 text-white rounded"
//           >
//             Undo
//           </button>
//           <button
//             onClick={redoAction}
//             className="px-4 py-2 bg-blue-500 text-white rounded"
//           >
//             Redo
//           </button>
//           <button
//             onClick={clearCanvas}
//             className="px-4 py-2 bg-red-500 text-white rounded"
//           >
//             Clear
//           </button>
//         </div>
//       </div>
//       <div className="flex-grow relative">
//         <ReactSketchCanvas
//           ref={canvasRef}
//           style={styles}
//           width="100%"
//           height="100%"
//           strokeWidth={4}
//           strokeColor="#000000"
//         />
//       </div>
//     </div>
//   );
// }


"use client";
import { useRef, useState } from 'react';
import { ReactSketchCanvas } from 'react-sketch-canvas';

export default function MyWhiteboard() {
  const canvasRef = useRef(null);
  const [strokeColor, setStrokeColor] = useState('#000000');
  const [isEraser, setIsEraser] = useState(false);
  
  const styles = {
    border: '1px solid #ccc',
    borderRadius: '4px',
  };
  
  const clearCanvas = () => {
    canvasRef.current.clearCanvas();
  };
  
  const undoAction = () => {
    canvasRef.current.undo();
  };
  
  const redoAction = () => {
    canvasRef.current.redo();
  };
  
  const changeColor = (color) => {
    setStrokeColor(color);
    setIsEraser(false);
  };
  
  const toggleEraser = () => {
    setIsEraser(true);
  };
  
  return (
    <div className="flex flex-col h-full w-full">
      <div className="flex justify-between items-center p-4 bg-gray-100 border-b">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => changeColor('#000000')}
            className="w-8 h-8 bg-black border border-gray-300 rounded-full"
          />
          <button
            onClick={() => changeColor('#FF0000')}
            className="w-8 h-8 bg-red-600 border border-gray-300 rounded-full"
          />
          <button
            onClick={() => changeColor('#0000FF')}
            className="w-8 h-8 bg-blue-600 border border-gray-300 rounded-full"
          />
          <button
            onClick={() => changeColor('#00FF00')}
            className="w-8 h-8 bg-green-600 border border-gray-300 rounded-full"
          />
          <button
            onClick={toggleEraser}
            className={`px-3 py-1 bg-white border rounded ${isEraser ? 'border-blue-500 bg-blue-100' : 'border-gray-300'}`}
          >
            Eraser
          </button>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={undoAction}
            className="px-4 py-2 bg-blue-500 text-white rounded"
          >
            Undo
          </button>
          <button
            onClick={redoAction}
            className="px-4 py-2 bg-blue-500 text-white rounded"
          >
            Redo
          </button>
          <button
            onClick={clearCanvas}
            className="px-4 py-2 bg-red-500 text-white rounded"
          >
            Clear
          </button>
        </div>
      </div>
      <div className="flex-grow relative min-h-[400px]">
        <ReactSketchCanvas
          ref={canvasRef}
          style={styles}
          width="100%"
          height="100%"
          strokeWidth={4}
          strokeColor={strokeColor}
          eraserWidth={20}
          eraseMode={isEraser}
        />
      </div>
    </div>
  );
}