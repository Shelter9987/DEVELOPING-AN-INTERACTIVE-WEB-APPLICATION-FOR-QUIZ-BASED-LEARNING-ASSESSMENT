"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { AiOutlineHome, AiOutlineRollback } from "react-icons/ai";
import { CgMailForward } from "react-icons/cg";

import { Button } from "@nextui-org/react";
import Link from "next/link";
const RoutesNav = ({ path = "/admin" }) => {
  const searchParams = useSearchParams();
  const router = useRouter();

  const auth = searchParams.get("q");
  return (
    <div className="flex justify-between items-center p-4 mb-2">
      <Button color="secondary" onClick={() => router.back()}>
        <AiOutlineRollback size={25} />
      </Button>
      <Button color="secondary" as={Link} href={path + "?" + auth}>
        <AiOutlineHome size={30} />
      </Button>
      <Button color="secondary" onClick={() => router.forward()}>
        <CgMailForward size={30} />{" "}
      </Button>
    </div>
  );
};

export default RoutesNav;
