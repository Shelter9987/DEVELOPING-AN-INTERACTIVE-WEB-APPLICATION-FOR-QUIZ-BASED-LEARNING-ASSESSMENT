import MyWhiteboard from '@/components/MyWhiteboard'
import React from 'react'

const WhiteboardPage = () => {
  return (
    <div>
      <MyWhiteboard />
    </div>
  )
}

export default WhiteboardPage
